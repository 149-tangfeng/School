/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50743
Source Host           : localhost:3306
Source Database       : project

Target Server Type    : MYSQL
Target Server Version : 50743
File Encoding         : 65001

Date: 2024-06-18 08:52:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for banner
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `img` varchar(255) DEFAULT NULL COMMENT '图片|image1',
  `sort_no` int(11) DEFAULT NULL COMMENT '排序号|number',
  `del_flag` int(11) DEFAULT '0' COMMENT '是否删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='轮播图';

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES ('1', 'http://localhost:8080/file?path=/upload/1793145950378745856/轮播图.png', '1', '0', '2024-04-15 11:40:40', 'admin');
INSERT INTO `banner` VALUES ('2', 'http://localhost:8080/file?path=/upload/1793145907039002624/轮播图.jpg', '0', '0', '2024-04-15 11:41:47', 'admin');
INSERT INTO `banner` VALUES ('3', 'http://localhost:8080/file?path=/upload/1780142465390166016/Snipaste_2024-04-16_15-30-36.png', '111', '1', '2024-04-16 15:53:34', 'admin');
INSERT INTO `banner` VALUES ('4', 'http://localhost:8080/file?path=/upload/1780155146218192896/Snipaste_2024-04-16_15-30-36.png', '1', '1', '2024-04-16 16:44:00', 'admin');
INSERT INTO `banner` VALUES ('5', 'http://localhost:8080/file?path=/upload/1793147169486757888/糕点素材图.png', '2', '0', '2024-05-22 13:09:39', 'admin');

-- ----------------------------
-- Table structure for bookmark
-- ----------------------------
DROP TABLE IF EXISTS `bookmark`;
CREATE TABLE `bookmark` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户|snumber',
  `data_id` bigint(20) DEFAULT NULL COMMENT '关联数据',
  `del_flag` int(11) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='收藏';

-- ----------------------------
-- Records of bookmark
-- ----------------------------
INSERT INTO `bookmark` VALUES ('3', '7', '1', '0', '2024-04-15 16:42:40', 'user5');
INSERT INTO `bookmark` VALUES ('6', '13', '7', '0', '2024-04-16 16:46:34', 'TEST');
INSERT INTO `bookmark` VALUES ('7', '7', '7', '0', '2024-04-17 17:31:20', 'user5');
INSERT INTO `bookmark` VALUES ('8', '14', '6', '0', '2024-05-06 03:14:02', '123');
INSERT INTO `bookmark` VALUES ('9', '18', '14', '0', '2024-05-30 14:15:04', 'Tfeng149');

-- ----------------------------
-- Table structure for cake
-- ----------------------------
DROP TABLE IF EXISTS `cake`;
CREATE TABLE `cake` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '蛋糕名|like',
  `img` varchar(255) DEFAULT NULL COMMENT '图片|image1',
  `content` text COMMENT '描述|rich',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `cate_id` varchar(255) DEFAULT NULL COMMENT '分类ID',
  `del_flag` int(10) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='蛋糕';

-- ----------------------------
-- Records of cake
-- ----------------------------
INSERT INTO `cake` VALUES ('3', '焦糖海绵蛋糕', 'http://localhost:8080/file?path=/upload/1780108766372134912/Snipaste_2024-04-16_13-39-05.png', '焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p><br></p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', '36.00', '1', '0', '2024-04-16 13:39:54', 'admin');
INSERT INTO `cake` VALUES ('4', '黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~</p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', '68.00', '4', '1', '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES ('5', '巧克力雪山黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~</p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', '68.00', '4', '0', '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES ('7', '香草布丁黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', '68.00', '4', '1', '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES ('8', '白菜校子', 'http://localhost:8080/file?path=/upload/1793147425473519616/白菜饺.png', '白菜饺是一道广受欢迎的传统中国食品，制作方法简单，口感美味。水饺外皮以面粉和水混合擀成，馅料主要由细肉、白菜和调味料混合而成，香气四溢。煮熟后，外皮Q弹可口，内馅多汁鲜香，味道鲜美，又香又辣。猪肉白菜水饺不仅是一种美食，也是一种象征着团圆和幸福的食品，在节庆和家庭聚会上经常被人们喜爱。', '56.00', '7', '0', '2024-05-22 13:14:57', 'admin');
INSERT INTO `cake` VALUES ('9', '至尊皇冠饺', 'http://localhost:8080/file?path=/upload/1793149481752027136/皇冠饺.png', '将新鲜的海胆肉和其他食材混合后作为饺子馅料，再包入饺子皮中煮熟。海胆肉具有细腻的质地和丰富的海洋味道，搭配上鲜嫩的饺子皮，口感丰富而滋味鲜美。海胆饺子有着独特的口感和味道，激发味蕾，令人回味无穷。这道美食不仅融合了海鲜的鲜美，也展现了中式饺子的传统魅力，是一道值得尝试的特色料理。', '65.00', '7', '0', '2024-05-22 13:20:01', 'admin');
INSERT INTO `cake` VALUES ('10', '金边锁链饺', 'http://localhost:8080/file?path=/upload/1793149897583714304/锁链饺.png', '金边锁链饺制作过程繁琐但口感十分美味。选用新鲜鲅鱼，剁成鱼肉茸，加入适量的调味料和蔬菜，制成饺子馅，包入薄而劲道的饺子皮内。煮熟后，饺子外皮筋道，内馅鱼肉香嫩鲜美，回味无穷。鲅鱼饺子富含蛋白质和各种营养，不仅味道鲜美，而且具有一定的健康价值。这道美食在制作工艺上颇为考究，被认为是一种传统的地方美食，深受人们喜爱。', '70.00', '7', '0', '2024-05-22 13:21:50', 'admin');
INSERT INTO `cake` VALUES ('11', '蟹黄包', 'http://localhost:8080/file?path=/upload/1793150530583879680/蟹黄包.jpg', '蟹黄包是一道粤菜中经典的小吃，以香滑的蟹黄为馅料，包裹在细腻的面皮内蒸制而成。蟹黄本身具有丰富的蛋白质和维生素，蟹黄包是一道粤菜中经典的点心，以蟹黄和猪肉为馅料包裹在香酥的面皮中而得名。蟹黄包馅料采用鲜嫩的蟹黄和精选的猪肉，口感鲜美且带有特殊的海鲜味道。面皮薄脆，包裹的馅料鲜香可口，一口咬下鲜汁四溢，让人回味无穷。蟹黄包是粤菜点心中的经典之作，不仅具有独特的美味，还展现了粤菜讲究食材的精髓和烹饪工艺的精湛，是一道受到食客喜爱的美食佳肴。', '81.00', '6', '0', '2024-05-22 13:23:14', 'admin');
INSERT INTO `cake` VALUES ('12', '奶黄包', 'http://localhost:8080/file?path=/upload/1793150649890856960/奶黄包.png', '奶黄包是一道受欢迎的中式点心，以甜美的奶黄馅料包裹在绵软的面皮中而得名。奶黄馅料通常由奶油、牛奶、蛋黄和糖等原料经过熬煮制成，口感细腻香甜。奶黄包外皮松软，内馅香甜可口，一口咬下甜蜜浓厚，带给人们愉悦的味觉享受。奶黄包既适合作为早餐点心或下午茶，也是家庭聚会或节庆喜庆时的常见美食。奶黄包是一道富有温馨回忆的经典点心，制作简单而口感绝佳，受到人们的喜爱。无论是外观还是口感都能让人一试难忘。', '47.00', '6', '0', '2024-05-22 13:23:50', 'admin');
INSERT INTO `cake` VALUES ('13', '元宝虾仁包', 'http://localhost:8080/file?path=/upload/1793150792828542976/虾仁包子.png', '虾仁包是一道粤式点心，以鲜美的虾仁为馅料包裹在细嫩的面皮中而得名。虾仁包外皮松软，内馅饱满且充满虾肉的鲜甜味道。虾仁包香气扑鼻，口感鲜美，吃起来既嫩滑又弹牙，香味四溢。虾仁包是中式点心中的经典之作，制作精细，口感十分美妙，被誉为广受欢迎的美食佳品。无论作为早茶点心或者晚餐小吃，虾仁包都是一道令人难以抵挡的美味佳肴，深受食客青睐。享用一口鲜美的虾仁包，仿佛能感受到家的温馨和厨师的用心烹饪，让人回味无穷。', '78.00', '6', '0', '2024-05-22 13:24:36', 'admin');
INSERT INTO `cake` VALUES ('14', '红糖三角包', 'http://localhost:8080/file?path=/upload/1793151335718281216/红糖三角包.png', '红糖包子是一种传统的中国传统小吃，以精选红糖为主要原料制作而成，外皮柔软，内馅香甜可口。红糖包子的馅料口感细腻，味道浓郁，散发着特有的红糖香味。制作红糖包子时，先将红糖和其他配料搅拌均匀，再包入蒸制好的面皮内，然后蒸熟即可食用。红糖包子在口感和味道上都非常独特，香甜可口，受到很多人的喜爱。红糖包子作为一种传统的中国小吃，具有浓厚的民俗风味，同时也承载着人们对美好生活的向往和祝愿。品尝一口红糖包子，仿佛能感受到家的温暖和甜蜜，让人充满幸福满足的感觉。', '40.00', '6', '0', '2024-05-22 13:26:33', 'admin');
INSERT INTO `cake` VALUES ('15', '梅花包', 'http://localhost:8080/file?path=/upload/1793151475929669632/梅花包子.png', '梅花包子是一种粤式传统点心，外形酷似梅花而得名。梅花包子通常是由细腻的面皮包裹着香甜可口的豆沙或肉馅料而制成。包子的外形像是一朵绽放的梅花，内馅则丰富鲜美。梅花包子外皮软糯，内馅口感细腻，既甜美又饱满。梅花包子不仅在味道上十分美味，同时其独特的形状也给人们带来视觉上的愉悦。作为一道粤式传统点心，梅花包子历史悠久，制作工艺精湛，是中式点心中的经典之一，受到人们的喜爱。品尝一口香甜可口的梅花包子，不仅能满足味蕾，更能感受到传统美食文化的魅力。', '60.00', '6', '0', '2024-05-22 13:27:22', 'admin');
INSERT INTO `cake` VALUES ('16', '葱花馅饼', 'http://localhost:8080/file?path=/upload/1793151726149263360/葱花馅饼.png', '葱花馅饼是一种口感香脆、味道浓郁的经典中式点心，深受人们喜爱。制作葱花馅饼时，通常选用面粉为主料，加入适量水和油揉成面团，再将葱花、盐和调味料混合制成馅料，包入面团内，擀成饼状后煎至金黄酥脆。葱花馅饼外皮香脆，内馅鲜香可口，葱香四溢，每一口都让人回味无穷。这道点心不仅口感独特，而且健康营养，葱花具有提神醒脑、促进消化的功效，是一道美味又健康的小吃选择。葱花馅饼适合作为早餐、下午茶或夜宵，凭借其独特的口感和香味，成为了中式点心中的一种经典美食。每当品尝一口香脆的葱花馅饼，都会被其美味所折服。', '30.00', '5', '0', '2024-05-22 13:28:11', 'admin');
INSERT INTO `cake` VALUES ('17', '苹果馅饼', 'http://localhost:8080/file?path=/upload/1793151903639625728/苹果馅饼.png', '苹果馅饼是一种美味清新的西式点心，以新鲜苹果为主要原料制作而成。制作苹果馅饼时，通常将苹果去皮去核，切成小块或片，与糖、肉桂粉等调味料混合制成馅料；然后将馅料包裹在酥脆的饼皮中，烘烤至金黄色即可。苹果馅饼的外皮松脆，内馅甜脆多汁，散发着苹果独特的清香，口感极为清新美妙。苹果馅饼不仅口感丰富，而且富含维生素和纤维，具有一定的营养价值，是一道适合各个年龄层享用的美味点心。无论是作为下午茶甜点，还是作为节日美食，苹果馅饼都能为人们带来愉悦的味蕾享受。食用一块热腾腾的苹果馅饼，享受那份清新与甜蜜，让人心情愉悦。', '40.00', '5', '0', '2024-05-22 13:28:48', 'admin');
INSERT INTO `cake` VALUES ('18', '牛肉馅饼', 'http://localhost:8080/file?path=/upload/1793152044786343936/牛肉馅饼.png', '牛肉馅饼是一种风味独特、营养丰富的美食，以碎牛肉为主要原料，搭配香料和蔬菜等食材制作而成。制作牛肉馅饼时，一般将牛肉剁成细碎，再加入葱姜蒜、香料和适量调味料拌匀，然后包入酥脆的馅饼皮中，煎炸至金黄酥脆。牛肉馅饼外皮酥脆香香，内馅肉味浓郁，口感丰富。牛肉馅饼不仅味道美味，而且蛋白质丰富，具有补充能量、增强体力的作用，是一道适合作为正餐或零食的美食选择。无论是搭配汤粥食用，还是当作早点下酒，牛肉馅饼都能为人们带来美味的享受。品尝一口香脆多汁的牛肉馅饼，恰似感受到风味独特的美食奇妙之处，让人回味无穷。', '53.00', '5', '0', '2024-05-22 13:29:18', 'admin');
INSERT INTO `cake` VALUES ('19', '广式蛋黄莲子月饼', 'http://localhost:8080/file?path=/upload/1793152244363911168/广式蛋黄莲子月饼.png', '广式蛋黄莲子月饼是一种传统的中秋节美食，具有浓厚的广东风味和独特的口感。这款月饼的外皮酥脆，内馅则包含了香甜的莲蓉和咸香的咸蛋黄，再加上香甜的莲子，口感丰富多样。制作广式蛋黄莲子月饼时，先将月饼皮包裹馅料，再在月饼表面放置一个金黄色的咸蛋黄作为装饰。莲子的加入为这款月饼增添了特殊的口感和香气，使得整个月饼更加美味。广式蛋黄莲子月饼不仅在味道上独具特色，而且在形状上也充满了节日氛围，是中秋节必不可少的传统食品之一。每当中秋佳节，家人团聚，品尝一块香甜可口的广式蛋黄莲子月饼，都能感受到浓浓的幸福和温馨。', '57.00', '8', '0', '2024-05-22 13:30:22', 'admin');
INSERT INTO `cake` VALUES ('20', '红豆松子月饼', 'http://localhost:8080/file?path=/upload/1793152442020487168/红豆松子月饼.png', '红豆松子月饼是一种口感独特、香甜可口的中式月饼，深受人们喜爱。这款月饼以红豆和松子为主要原料，制作工艺精湛。月饼的外皮酥脆，内馅则包含了细腻的红豆馅和香气扑鼻的松子，口感丰富，香甜可口。制作红豆松子月饼时，先将红豆熬煮成细腻的红豆馅，再加入香气独特的松子，搅拌均匀作为内馅，包裹在月饼皮内，经过烘烤制成。红豆的甜味与松子的香气相互融合，带来独特的美味享受。红豆松子月饼不仅口感丰富，而且具有一定的营养价值，红豆富含蛋白质和纤维，松子则富含不饱和脂肪酸和维生素。无论是作为中秋节的传统美食，还是作为下午茶的点心，红豆松子月饼都能为人们带来愉悦的味蕾享受。品尝一块香甜可口的红豆松子月饼，感受其中蕴含的浓浓美味和节日的喜庆氛围。', '55.00', '8', '0', '2024-05-22 13:30:55', 'admin');
INSERT INTO `cake` VALUES ('21', '栗子月饼', 'http://localhost:8080/file?path=/upload/1793152578062737408/栗子月饼.png', '栗子月饼是一种传统的中式月饼，以栗子为主要原料制作而成，口感香甜独特。这款月饼的外皮酥脆，内馅则包含了细腻的栗子泥，带有浓厚的栗子香味，让人回味无穷。制作栗子月饼时，先将栗子煮熟、去壳、捣成泥状，再加入适量糖和其他调味料，制成馅料，包裹在月饼皮内，经过烘烤制成。栗子月饼的香甜味道和浓厚的栗子香气，给人一种温暖和满足的感觉。栗子富含淀粉、蛋白质和维生素，有助于增加能量和提供营养，是一种美味又营养的中式点心。无论是作为中秋节的美食佳品，还是作为下午茶的甜点，栗子月饼都能带来愉悦的味蕾享受。品尝一块香甜可口的栗子月饼，感受其中蕴含的栗子独特风味和节日的喜庆氛围。', '57.00', '8', '0', '2024-05-22 13:31:28', 'admin');
INSERT INTO `cake` VALUES ('22', '苏式月饼', 'http://localhost:8080/file?path=/upload/1793152718701944832/苏式月饼.png', '苏式月饼是一种具有江苏地区特色的传统中式月饼，口感细腻，香甜可口。这款月饼的外皮薄而酥，内馅丰富多样，常见的口味包括豆沙、莲蓉、五仁等。制作苏式月饼时，外皮采用传统的糕点皮制作，内馅则根据口味需求选择不同的馅料，经过精心制作而成。苏式月饼在口感上追求细腻和平衡，既有外皮的酥脆，又有内馅的香甜，让人回味无穷。苏式月饼的制作工艺经过精心传承，每一口都带有浓厚的地方特色和传统风味。无论是作为节日礼品，还是作为下午茶的点心，苏式月饼都能为人们带来愉悦的味蕾享受。品尝一块香甜可口的苏式月饼，感受其中蕴含的地方特色和传统文化的魅力。', '56.00', '8', '0', '2024-05-22 13:32:01', 'admin');
INSERT INTO `cake` VALUES ('23', '皮蛋酥饼', 'http://localhost:8080/file?path=/upload/1793152890697768960/包皮蛋酥饼.png', '皮蛋酥饼的独特口感和香气令人难以忘怀，口感香脆，具有浓厚的地方特色。皮蛋酥饼的制作工艺比较复杂，首先将面粉、油脂等原料和水搅拌均匀，揉成面团，酥饼皮需反复擀制，再在面团上加入磨碎的皮蛋和适量的调味料，将其包裹在饼皮内，再进行煎炸至金黄酥脆。皮蛋酥饼既有外皮的酥脆，又有内馅的香味，是一款老少皆宜的美食。声名在外，备受人们喜爱。无论是作为小吃零食，还是作为下酒佳品，皮蛋酥饼都能为人们带来美味享受。品尝一口香脆多汁的皮蛋酥饼，感受其中独特的风味和浓厚的地方特色，在舌尖留下难以磨灭的美好记忆。', '64.00', '9', '0', '2024-05-22 13:33:05', 'admin');
INSERT INTO `cake` VALUES ('24', '水果粽子', 'http://localhost:8080/file?path=/upload/1796063192879849472/水果粽子.jpg', '<p>水果粽子</p>', '67.00', '10', '1', '2024-05-30 14:17:00', 'admin');

-- ----------------------------
-- Table structure for cate
-- ----------------------------
DROP TABLE IF EXISTS `cate`;
CREATE TABLE `cate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '分类名|like',
  `img` varchar(255) DEFAULT NULL COMMENT '图片|image1',
  `del_flag` int(10) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='蛋糕分类';

-- ----------------------------
-- Records of cate
-- ----------------------------
INSERT INTO `cate` VALUES ('1', '海绵', 'http://localhost:8080/file?path=/upload/1779370851140624384/Snipaste_2024-04-14_12-47-12.png', '1', '2024-04-14 12:47:26', 'admin');
INSERT INTO `cate` VALUES ('2', '慕斯', 'http://localhost:8080/file?path=/upload/1779425079074619392/Snipaste_2024-04-14_16-22-46.png', '0', '2024-04-14 16:22:55', 'admin');
INSERT INTO `cate` VALUES ('3', '提拉米苏', 'http://localhost:8080/file?path=/upload/1780109230039859200/Snipaste_2024-04-16_13-41-20.png', '0', '2024-04-16 13:41:29', 'admin');
INSERT INTO `cate` VALUES ('4', '黑森林', 'http://localhost:8080/file?path=/upload/1780109563243757568/Snipaste_2024-04-16_13-42-37.png', '0', '2024-04-16 13:42:48', 'admin');
INSERT INTO `cate` VALUES ('5', '馅饼', 'http://localhost:8080/file?path=/upload/1793147067472896000/馅饼.png', '0', '2024-05-22 13:09:12', 'admin');
INSERT INTO `cate` VALUES ('6', '包子', 'http://localhost:8080/file?path=/upload/1793147096552005632/包子.png', '0', '2024-05-22 13:09:21', 'admin');
INSERT INTO `cate` VALUES ('7', '饺子', 'http://localhost:8080/file?path=/upload/1793147230669070336/饺子.png', '0', '2024-05-22 13:09:53', 'admin');
INSERT INTO `cate` VALUES ('8', '月饼', 'http://localhost:8080/file?path=/upload/1793149234762047488/月饼.png', '0', '2024-05-22 13:17:51', 'admin');
INSERT INTO `cate` VALUES ('9', '酥饼', 'http://localhost:8080/file?path=/upload/1793150368323035136/酥饼.png', '0', '2024-05-22 13:22:23', 'admin');
INSERT INTO `cate` VALUES ('10', '粽子', 'http://localhost:8080/file?path=/upload/1796063112420515840/粽子.jpg', '0', '2024-05-30 14:16:35', 'admin');

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_id` bigint(20) DEFAULT NULL COMMENT '评论对象ID',
  `content` varchar(255) DEFAULT NULL COMMENT '评论内容',
  `del_flag` int(10) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人|like',
  `p_id` bigint(20) DEFAULT '0' COMMENT '上级评论ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT '评论人用户ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='商品评论';

-- ----------------------------
-- Records of comments
-- ----------------------------
INSERT INTO `comments` VALUES ('2', '1', '123', '1', '2024-04-15 19:47:07', 'user5', '0', '7');
INSERT INTO `comments` VALUES ('3', '2', '123333', '1', '2024-04-15 19:47:22', 'user5', '0', '7');
INSERT INTO `comments` VALUES ('4', '1', '1231232131232', '1', '2024-04-15 19:57:34', 'user5', '0', '7');
INSERT INTO `comments` VALUES ('6', '7', '不怎么好吃~吃', '1', '2024-04-16 16:17:15', 'hahahaha', '0', '11');
INSERT INTO `comments` VALUES ('7', '7', '好吃😋', '1', '2024-04-16 16:47:04', 'TEST', '0', '13');
INSERT INTO `comments` VALUES ('8', '7', '12345611111', '1', '2024-04-17 17:31:37', 'user5', '0', '7');
INSERT INTO `comments` VALUES ('9', '6', '不好吃', '1', '2024-04-29 14:57:19', '123', '0', '14');
INSERT INTO `comments` VALUES ('10', '6', '1111', '1', '2024-04-29 17:18:02', '123', '0', '14');
INSERT INTO `comments` VALUES ('11', '6', '还不错', '1', '2024-05-20 01:58:27', '123', '0', '14');
INSERT INTO `comments` VALUES ('12', '6', '不怎么样', '1', '2024-05-20 02:11:47', '123', '0', '14');
INSERT INTO `comments` VALUES ('13', '20', '好吃，下次还会购买', '1', '2024-05-23 14:55:18', 'xiaolong123', '0', '15');
INSERT INTO `comments` VALUES ('14', '20', '这个月饼味道不错，家里老人小孩都喜欢吃', '0', '2024-05-23 15:47:01', 'xiaolong123', '0', '15');
INSERT INTO `comments` VALUES ('15', '14', '不好吃', '1', '2024-05-30 14:15:16', 'Tfeng149', '0', '18');
INSERT INTO `comments` VALUES ('16', '14', '皮薄馅多，红糖也是选用的上等红糖，比其他地方买的好多了。', '0', '2024-06-04 16:38:33', 'Tfeng149', '0', '18');
INSERT INTO `comments` VALUES ('17', '15', '这个包子我买了一千克尝尝，字如其名，不仅外观好看，里面的使用的梅花馅也很不错，吃完口齿留香。', '0', '2024-06-04 16:45:11', 'Tfeng149', '0', '18');

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户|snumber',
  `content` varchar(255) DEFAULT NULL COMMENT '内容|like|textarea',
  `reply` varchar(255) DEFAULT NULL COMMENT '回复|textarea',
  `feedback_status` varchar(255) DEFAULT NULL COMMENT '精选|eq',
  `del_flag` int(11) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='留言板';

-- ----------------------------
-- Records of feedback
-- ----------------------------
INSERT INTO `feedback` VALUES ('1', '1', '你好啊', '123', null, '1', '2024-03-31 03:10:43', 'user1');
INSERT INTO `feedback` VALUES ('2', '1', '啊打发士大夫', '22222222', '精选', '1', '2024-03-31 03:11:43', 'user1');
INSERT INTO `feedback` VALUES ('3', '7', '李四啊啊啊', 'OKOKOK', '精选', '1', '2024-03-31 15:42:03', 'user5');
INSERT INTO `feedback` VALUES ('4', '7', '123123', null, null, '1', '2024-04-13 13:55:58', 'user5');
INSERT INTO `feedback` VALUES ('5', '7', '12313', '111', null, '1', '2024-04-15 18:22:49', 'user5');
INSERT INTO `feedback` VALUES ('6', '11', '123', null, null, '1', '2024-04-16 16:39:28', 'hahahaha');
INSERT INTO `feedback` VALUES ('7', '13', '做得很好', null, null, '1', '2024-04-16 16:47:28', 'TEST');
INSERT INTO `feedback` VALUES ('8', '7', '测试评论', null, null, '1', '2024-04-17 16:53:03', 'user5');
INSERT INTO `feedback` VALUES ('9', '7', '测试评论输入~', null, null, '1', '2024-04-17 17:31:57', 'user5');
INSERT INTO `feedback` VALUES ('10', '14', null, null, null, '1', '2024-04-29 14:56:57', '123');
INSERT INTO `feedback` VALUES ('11', '14', '11111', null, null, '1', '2024-04-29 14:57:01', '123');
INSERT INTO `feedback` VALUES ('12', '14', null, null, null, '1', '2024-04-29 17:18:58', '123');
INSERT INTO `feedback` VALUES ('16', '15', '糕点数量还是有些少，期望以后能够上架更多糕点。', '感谢您的支持与反馈，我们会后续跟进', '精选', '0', '2024-05-23 17:06:36', 'xiaolong123');
INSERT INTO `feedback` VALUES ('17', '18', '糕点数量有些少', '收到反馈', '精选', '0', '2024-05-30 14:15:40', 'Tfeng149');
INSERT INTO `feedback` VALUES ('18', '18', '经常在你家买东西，感觉糕点用馅都挺扎实的，价格还实惠，我以后也推荐推荐亲朋好友来买点。', null, null, '0', '2024-06-04 16:37:37', 'Tfeng149');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) DEFAULT NULL COMMENT '标题|like',
  `content` text COMMENT '正文|rich',
  `del_flag` int(11) DEFAULT '0' COMMENT '是否删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='公告';

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '热烈庆祝我司与著名蛋糕连锁品牌罗森妮娜达成战略合作！！！', '<p class=\"ql-align-center\"><strong class=\"ql-size-large\">热烈庆祝我司与著名蛋糕连锁品牌罗森妮娜达成战略合作！！！</strong></p><p><img src=\"http://localhost:8080/file?path=/upload/1779717172443725824/5dc379ed728061691.jpg_e1080.jpg\"></p><p><br></p><p><br></p><p>	<span style=\"color: rgb(51, 51, 51);\">湖南罗森尼娜食品有限公司于2015年10月27日成立。法定代表人朱满文,公司经营范围包括：糕点、面包、饼干及其他焙烤食品、速冻食品、蔬菜、水果罐头、糖果、巧克力的制造；糕点、面包、咖啡器具的零售；预包装食品、散装食品、水果、乳制品的销售；冷热饮品制售；西餐服务；中餐服务；烘焙食品制造（现场制售）；水果和坚果加工；水果的冷冻冷藏；蜜饯制作；咖啡馆服务等。</span></p>', '1', '2024-04-15 11:44:50', 'admin');
INSERT INTO `notice` VALUES ('2', '测送上', '<p>测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上</p>', '1', '2024-04-16 15:53:56', 'admin');
INSERT INTO `notice` VALUES ('3', '测试', '<p>测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试</p>', '1', '2024-04-16 16:44:18', 'admin');
INSERT INTO `notice` VALUES ('4', '糕点的诱人滋味', '<p data-sider-select-id=\"2e13643a-c3d8-486f-bb93-cd5325e48358\">糕点,这种精致的小吃,早已成为人们生活中不可或缺的一部分。从古至今,各地都拥有自己独特的糕点文化,每一种都蕴含着丰富的历史传统和人文内涵。</p><p data-sider-select-id=\"2e13643a-c3d8-486f-bb93-cd5325e48358\">糕点的制作工艺讲究繁复,需要经验丰富的烘焙师傅精心把控每一个步骤。首先,要选用优质的原料,如高筋面粉、鸡蛋、奶油等。然后是精心调配比例,掌握发酵、烘焙的关键技巧。最后,还需要巧手雕刻成各种精美的造型,点缀上色彩艳丽的装饰。</p><p data-sider-select-id=\"2e13643a-c3d8-486f-bb93-cd5325e48358\">每一种糕点都有自己独特的风味。有的香甜柔软,入口即化;有的清香酥脆,回味无穷;有的馅料丰富,口感层次分明。无论是传统的红豆糕、奶黄包,还是创新的抹茶蛋糕、水晶冰糖糕,都能给人以视觉和味觉的双重享受。</p><p data-sider-select-id=\"2e13643a-c3d8-486f-bb93-cd5325e48358\">糕点不仅可以作为日常小吃,在节庆活动中更是必不可少的佳品。在中秋节品尝月饼,在春节品尝年糕,都是中华民族重要的饮食文化传统。这些糕点不仅美味可口,更承载着浓厚的文化内涵和家国情怀。</p><p>如今,随着时代的发展,糕点制作工艺也在不断创新,种类越来越丰富多样。无论是传统工艺还是现代fusion,每一种糕点都散发着独特的魅力,勾起人们对美好生活的向往。让我们一起拥抱这份来自美味与文化的双重馈赠,享受糕点带来的无穷乐趣吧。</p>', '0', '2024-04-17 15:17:49', 'admin');
INSERT INTO `notice` VALUES ('5', '糕点行业的创新与颠覆 - 从传统到新潮', '<p>糕点作为一个传统行业,近年来却呈现出了不少新的变革趋势。随着消费者需求的不断升级,以及互联网技术的深度渗透,糕点行业正在经历一场前所未有的创新与颠覆。</p><p>传统糕点店面临的挑战 传统糕点店凭借着自身积累多年的口碑和技艺,在行业内占据着一定的优势。但随着生活节奏的加快,消费者对于糕点的需求也发生了变化。他们不仅追求更加新颖独特的口味,同时也希望能够在下单、配送等环节享受到更加便捷高效的服务。而这正是许多传统糕点店所缺乏的。</p><p>互联网+糕点的创新模式 互联网时代的到来,为糕点行业带来了新的机遇。一些新兴的糕点品牌开始探索\"互联网+糕点\"的创新模式,利用移动支付、社交媒体等数字化手段,实现了更精准的用户画像和精细化运营。同时,借助于电商平台,这些品牌也能够实现全国性的销售网络,打破了地域限制,为消费者提供更加便捷的购买体验。</p><p>从定制化到个性化 在消费升级的大趋势下,定制化糕点正日益受到消费者的青睐。许多品牌开始推出个性化定制服务,让消费者可以自主设计糕点的造型、口味等参数,满足自身的独特需求。这不仅增强了消费者的互动体验,也进一步推动了糕点行业向个性化方向发展。</p><p>总的来说,在新技术、新需求的推动下,糕点行业正在经历一场深刻的转型。传统企业需要与时俱进,拥抱创新,才能在激烈的市场竞争中立于不败之地。</p>', '0', '2024-06-04 16:48:46', 'admin');
INSERT INTO `notice` VALUES ('6', '糕点行业的前景分析:从\"甜品\"到\"生活方式\"', '<p>作为一个传统的消费品行业,糕点行业近年来也掀起了一波新的发展热潮。从单纯的\"甜品\"消费,到逐步融入生活方式,糕点行业正在经历着一场质的飞跃。</p><p>糕点消费升级的动力 随着人们生活水平的不断提高,消费升级已经成为一种普遍趋势。对于糕点行业而言,这种消费升级主要体现在:</p><ol><li>口味需求更加细分和个性化。除了传统的蛋糕、月饼等,消费者开始追求更加创新、富有特色的口味。</li><li>消费场景更加多元化。糕点不再仅仅局限于节庆、喜庆等场合,而是融入到日常生活的各个方面。</li><li>对品质和服务的要求不断提高。消费者不仅关注糕点的口味,同时也越来越注重制作工艺、包装设计等方面。</li></ol><p>从\"甜品\"到\"生活方式\" 随着消费升级的推动,糕点行业正在不断向\"生活方式\"延伸。一些引领潮流的品牌开始将糕点与艺术、文化等元素相结合,打造出富有个性和故事性的产品。这不仅满足了消费者对于独特体验的需求,也进一步拓展了糕点的消费场景。</p><p>与此同时,糕点行业也开始注重打造自身的品牌形象和文化内涵。通过线上线下结合的营销方式,以及与其他行业的跨界合作,这些品牌正在努力将糕点塑造成一种\"生活方式\"。</p><p>从这个角度来看,糕点行业的前景十分广阔。只要能够紧跟消费需求的变化,不断创新,糕点行业必将成为消费市场上的一颗璀璨明珠。</p>', '0', '2024-06-04 16:49:00', 'admin');
INSERT INTO `notice` VALUES ('7', '糕点行业的发展趋势与挑战', '<p>近年来,随着消费需求的不断升级,糕点行业也掀起了一场新的变革热潮。从口味创新到营销模式,再到行业格局的重塑,糕点企业正在积极应对着一系列的发展趋势和挑战。</p><p>特色口味与个性化定制 随着生活品质的提升,消费者对于糕点的需求已经从单一的甜点转变为更加细分和个性化的要求。一些创新型的糕点品牌开始尝试将异国风情、文化元素融入自身的产品,满足消费者独特的口味偏好。同时,个性化定制服务也越来越受到青睐,让消费者能够根据自身需求定制糕点的造型、口味等。</p><p>线上线下融合发展 借助互联网技术,糕点行业掀起了一场\"线上线下\"融合的发展浪潮。一方面,电商平台为糕点品牌提供了全新的销售渠道,打破了地域界限,实现了全国性的商品销售。另一方面,线下门店也开始重视消费者的体验感受,通过门店设计、服务升级等方式,提升消费者的互动参与度。</p><p>新兴业态与跨界合作 在消费升级的大趋势下,糕点行业也涌现出了许多新兴业态。有的品牌将糕点与艺术、养生等元素相结合,打造出富有特色的\"生活方式\"。有的则通过与餐饮、旅游等行业的跨界合作,为消费者带来更加丰富的体验。这些创新实践不仅拓宽了糕点行业的发展空间,也进一步推动了整个行业的转型升级。</p><p>挑战与未来 尽管糕点行业掀起了一波新的发展热潮,但同时也面临着不少挑战。如何在激烈的市场竞争中脱颖而出?如何把握消费需求的变化并做出快速反应?如何实现线上线下的深度融合?这些都是摆在糕点企业面前的重要课题。</p><p>总的来说,糕点行业正处于一个关键的转型期。只有紧跟时代脉搏,不断创新,糕点企业才能在未来的竞争中占据有利位置,实现可持续发展。</p>', '0', '2024-06-04 16:49:11', 'admin');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `cake_id` bigint(20) DEFAULT NULL COMMENT '蛋糕ID',
  `cake_name` varchar(255) DEFAULT NULL COMMENT '蛋糕名|like',
  `cate_id` bigint(20) DEFAULT NULL COMMENT '蛋糕分类ID',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `quantity` int(10) DEFAULT NULL COMMENT '数量',
  `cost` decimal(10,2) DEFAULT NULL COMMENT '订单金额',
  `sn` varchar(255) DEFAULT NULL COMMENT '订单编号',
  `del_flag` int(10) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='订单';

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1', '7', '2', '樱花草莓奥利奥慕斯蛋糕', '2', '68.00', '11', '748.00', '202404151840252260001', '1', '2024-04-15 18:40:25', 'user5');
INSERT INTO `orders` VALUES ('2', '7', '1', '海绵蛋糕XXO', '1', '13.00', '2', '26.00', '202404151840415590002', '1', '2024-04-15 18:40:42', 'user5');
INSERT INTO `orders` VALUES ('3', '5', '2', '樱花草莓奥利奥慕斯蛋糕', '2', '68.00', '12', '816.00', '202404161213572190001', '1', '2024-04-16 12:13:58', 'user4');
INSERT INTO `orders` VALUES ('4', '8', '1', '海绵蛋糕XXO', '1', '13.00', '1', '13.00', '202404161239376240002', '1', '2024-04-16 12:39:38', 'user6');
INSERT INTO `orders` VALUES ('5', '8', '4', '黑森林蛋糕', '4', '68.00', '4', '340.00', '202404161345237420001', '1', '2024-04-16 13:45:24', 'user6');
INSERT INTO `orders` VALUES ('6', '3', '5', '巧克力雪山黑森林蛋糕', '4', '68.00', '6', '408.00', '202404161513116730002', '1', '2024-04-16 15:13:11', 'user2');
INSERT INTO `orders` VALUES ('7', '3', '6', '草莓布丁黑森林蛋糕', '4', '68.00', '5', '340.00', '202404161513221930003', '1', '2024-04-16 15:13:22', 'user2');
INSERT INTO `orders` VALUES ('8', '3', '7', '香草布丁黑森林蛋糕', '4', '68.00', '7', '476.00', '202404161513296070004', '1', '2024-04-16 15:13:30', 'user2');
INSERT INTO `orders` VALUES ('9', '3', '3', '焦糖海绵蛋糕', '1', '36.00', '9', '324.00', '202404161514175430005', '1', '2024-04-16 15:14:18', 'user2');
INSERT INTO `orders` VALUES ('10', '3', '1', '海绵蛋糕XXO', '1', '13.00', '12', '156.00', '202404161514468150006', '1', '2024-04-16 15:14:47', 'user2');
INSERT INTO `orders` VALUES ('11', '11', '7', '香草布丁黑森林蛋糕', '4', '68.00', '12', '816.00', '202404161616459920001', '1', '2024-04-16 16:16:45', 'hahahaha');
INSERT INTO `orders` VALUES ('12', '13', '7', '香草布丁黑森林蛋糕', '4', '68.00', '2', '136.00', '202404161646504110002', '1', '2024-04-16 16:46:50', 'TEST');
INSERT INTO `orders` VALUES ('13', '7', '7', '香草布丁黑森林蛋糕', '4', '68.00', '12', '816.00', '202404171731258390001', '1', '2024-04-17 17:31:26', 'user5');
INSERT INTO `orders` VALUES ('14', '14', '6', '草莓布丁黑森林蛋糕', '4', '68.00', '1', '68.00', '202404281546251020001', '1', '2024-04-28 15:46:25', '123');
INSERT INTO `orders` VALUES ('15', '14', '6', '草莓布丁黑森林蛋糕', '4', '68.00', '1', '68.00', '202404291456531600001', '1', '2024-04-29 14:56:54', '123');
INSERT INTO `orders` VALUES ('16', '15', '20', '红豆松子月饼', '8', '55.00', '1', '55.00', '202405221425282500001', '0', '2024-05-22 14:25:29', 'xiaolong123');
INSERT INTO `orders` VALUES ('17', '18', '20', '红豆松子月饼', '8', '55.00', '1', '55.00', '202405231508199900001', '0', '2024-05-23 15:08:20', 'Tfeng149');
INSERT INTO `orders` VALUES ('18', '18', '14', '红糖三角包', '6', '40.00', '10', '400.00', '202405301415029640001', '0', '2024-05-30 14:15:03', 'Tfeng149');
INSERT INTO `orders` VALUES ('19', '18', '15', '梅花包', '6', '60.00', '1', '60.00', '202406041643579500001', '0', '2024-06-04 16:43:57', 'Tfeng149');

-- ----------------------------
-- Table structure for registration
-- ----------------------------
DROP TABLE IF EXISTS `registration`;
CREATE TABLE `registration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `activity_id` bigint(20) DEFAULT NULL COMMENT '活动|snumber',
  `user_id` bigint(20) DEFAULT NULL COMMENT '报名用户|snumber',
  `del_flag` int(11) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='活动报名';

-- ----------------------------
-- Records of registration
-- ----------------------------
INSERT INTO `registration` VALUES ('2', '2', '1', '0', '2024-03-31 04:34:22', 'user1');
INSERT INTO `registration` VALUES ('3', '3', '7', '0', '2024-03-31 15:45:12', 'user5');
INSERT INTO `registration` VALUES ('4', '3', '5', '0', '2024-03-31 15:45:24', 'user4');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_type` varchar(255) DEFAULT NULL COMMENT '类型|select|eq',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名|like',
  `pwd` varchar(255) DEFAULT NULL COMMENT '密码|password',
  `display_name` varchar(255) DEFAULT NULL COMMENT '姓名|like',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别|select|eq',
  `age` int(11) DEFAULT NULL COMMENT '年龄|number',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号|like',
  `img` varchar(255) DEFAULT NULL COMMENT '头像|image1',
  `del_flag` int(11) DEFAULT '0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户';

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', '管理员', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '22', '18674593281', 'http://localhost:8080/file?path=/upload/1780155494374785024/Snipaste_2024-04-16_15-30-51.png', '0', '2024-03-30 19:44:33', 'admin');
INSERT INTO `sys_user` VALUES ('2', '管理员', 'admin2', 'e10adc3949ba59abbe56e057f20f883e', '管111', '男', '22', '16655554444', 'http://localhost:8080/file?path=/upload/1774340287986700288/9.jpg', '0', '2024-03-30 19:44:33', 'admin');
INSERT INTO `sys_user` VALUES ('3', '用户', 'user2', 'e10adc3949ba59abbe56e057f20f883e', 'user2', '男', '22', '15588885555', 'http://localhost:8080/file?path=/upload/1774045535139581952/3.jpg', '1', '2024-03-30 20:06:31', 'admin');
INSERT INTO `sys_user` VALUES ('4', '用户', 'user3', 'e10adc3949ba59abbe56e057f20f883e', 'user3', '女', '21', '15544441111', 'http://localhost:8080/file?path=/upload/1774045840057163776/4.jpg', '1', '2024-03-30 20:07:44', 'admin');
INSERT INTO `sys_user` VALUES ('5', '管理员', 'admin5', 'e10adc3949ba59abbe56e057f20f883e', '管111', '男', '22', '16655554444', 'http://localhost:8080/file?path=/upload/1774340287986700288/9.jpg', '0', '2024-03-30 19:44:33', 'admin');
INSERT INTO `sys_user` VALUES ('6', '用户', '1', 'bea43f5f7ad39e2d184cb16885043d42', '1', '男', '11', '12311111111', 'http://localhost:8080/file?path=/upload/1774340632657825792/4.jpg', '1', '2024-03-31 15:39:08', 'admin');
INSERT INTO `sys_user` VALUES ('7', '用户', 'user5', 'e10adc3949ba59abbe56e057f20f883e', '李四', '男', '22', '13555555555', 'http://localhost:8080/file?path=/upload/1774341128244203520/5.jpg', '1', '2024-03-31 15:41:06', '注册');
INSERT INTO `sys_user` VALUES ('8', '用户', 'user6', 'e10adc3949ba59abbe56e057f20f883e', 'test', '男', '22', '13012345678', 'http://localhost:8080/file?path=/upload/1780141927961411584/Snipaste_2024-04-16_15-30-36.png', '1', '2024-04-16 12:38:26', 'admin');
INSERT INTO `sys_user` VALUES ('9', '用户', 'user9', 'e10adc3949ba59abbe56e057f20f883e', 'user9', '男', '12', '18612345678', 'http://localhost:8080/file?path=/upload/1780137682264621056/Snipaste_2024-04-16_15-30-51.png', '1', '2024-04-16 15:34:33', 'admin');
INSERT INTO `sys_user` VALUES ('10', '用户', 'test', 'e10adc3949ba59abbe56e057f20f883e', 'test', '女', '13', '13012345678', 'http://localhost:8080/file?path=/upload/1780143898734837760/Snipaste_2024-04-16_15-30-51.png', '1', '2024-04-16 15:59:15', 'admin');
INSERT INTO `sys_user` VALUES ('11', '用户', 'hahahaha', 'e10adc3949ba59abbe56e057f20f883e', 'haha', '男', '21', '13012345678', 'http://localhost:8080/file?path=/upload/1780148182213935104/Snipaste_2024-04-16_15-30-51.png', '1', '2024-04-16 16:16:16', '注册');
INSERT INTO `sys_user` VALUES ('12', '用户', 'hahaha1', 'e10adc3949ba59abbe56e057f20f883e', 'hahaha', '男', '21', '13012345678', 'http://localhost:8080/file?path=/upload/1780154745662160896/Snipaste_2024-04-16_15-30-36.png', '1', '2024-04-16 16:42:10', 'admin');
INSERT INTO `sys_user` VALUES ('13', '用户', 'TEST', 'e10adc3949ba59abbe56e057f20f883e', 'TEST', '男', '21', '13012345678', 'http://localhost:8080/file?path=/upload/1780155756573310976/Snipaste_2024-04-16_15-30-51.png', '1', '2024-04-16 16:46:22', '注册');
INSERT INTO `sys_user` VALUES ('14', '用户', '123', '202cb962ac59075b964b07152d234b70', '12', '男', '11', '181111111111', 'http://localhost:8080/file?path=/upload/1784425305335717888/vite.png', '1', '2024-04-28 11:32:02', '注册');
INSERT INTO `sys_user` VALUES ('15', '用户', 'xiaolong123', 'e10adc3949ba59abbe56e057f20f883e', '龙龙', '男', '23', '19748532619', 'http://localhost:8080/file?path=/upload/1793146179555516416/头像01.png', '0', '2024-05-22 13:05:40', 'admin');
INSERT INTO `sys_user` VALUES ('16', '用户', 'xiaowei520', 'e10adc3949ba59abbe56e057f20f883e', '宋曦薇', '女', '24', '19876452301', 'http://localhost:8080/file?path=/upload/1793146633400180736/头像.jpeg', '0', '2024-05-22 13:07:28', 'admin');
INSERT INTO `sys_user` VALUES ('17', '用户', 'zhangwei3340', 'e10adc3949ba59abbe56e057f20f883e', '张威', '男', '25', '19523687429', 'http://localhost:8080/file?path=/upload/1793146873528279040/头像02.png', '0', '2024-05-22 13:08:26', 'admin');
INSERT INTO `sys_user` VALUES ('18', '用户', 'Tfeng149', 'e10adc3949ba59abbe56e057f20f883e', '吴先生', '男', '24', '18741136921', 'http://localhost:8080/file?path=/upload/1793501715912323072/头像01.png', '0', '2024-05-23 12:39:05', '注册');
