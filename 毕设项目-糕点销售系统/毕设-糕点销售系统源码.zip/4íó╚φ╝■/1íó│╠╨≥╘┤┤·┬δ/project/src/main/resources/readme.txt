vm options
--add-opens java.base/java.lang.invoke=ALL-UNNAMED
