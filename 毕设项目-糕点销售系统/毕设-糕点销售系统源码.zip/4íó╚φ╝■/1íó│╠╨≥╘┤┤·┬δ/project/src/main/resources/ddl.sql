/*
 Navicat Premium Data Transfer

 Source Server         : LOCAL
 Source Server Type    : MySQL
 Source Server Version : 50741 (5.7.41-log)
 Source Host           : localhost:3306
 Source Schema         : project

 Target Server Type    : MySQL
 Target Server Version : 50741 (5.7.41-log)
 File Encoding         : 65001

 Date: 17/04/2024 22:52:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for banner
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片|image1',
  `sort_no` int(11) NULL DEFAULT NULL COMMENT '排序号|number',
  `del_flag` int(11) NULL DEFAULT 0 COMMENT '是否删除',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '轮播图' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES (1, 'http://localhost:8080/file?path=/upload/1779716432975347712/102-20061GI333154.jpg', 1, 0, '2024-04-15 11:40:40', 'admin');
INSERT INTO `banner` VALUES (2, 'http://localhost:8080/file?path=/upload/1779716699955380224/5dc379ed728061691.jpg_e1080.jpg', 0, 0, '2024-04-15 11:41:47', 'admin');
INSERT INTO `banner` VALUES (3, 'http://localhost:8080/file?path=/upload/1780142465390166016/Snipaste_2024-04-16_15-30-36.png', 111, 1, '2024-04-16 15:53:34', 'admin');
INSERT INTO `banner` VALUES (4, 'http://localhost:8080/file?path=/upload/1780155146218192896/Snipaste_2024-04-16_15-30-36.png', 1, 1, '2024-04-16 16:44:00', 'admin');

-- ----------------------------
-- Table structure for bookmark
-- ----------------------------
DROP TABLE IF EXISTS `bookmark`;
CREATE TABLE `bookmark`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户|snumber',
  `data_id` bigint(20) NULL DEFAULT NULL COMMENT '关联数据',
  `del_flag` int(11) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '收藏' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of bookmark
-- ----------------------------
INSERT INTO `bookmark` VALUES (3, 7, 1, 0, '2024-04-15 16:42:40', 'user5');
INSERT INTO `bookmark` VALUES (6, 13, 7, 0, '2024-04-16 16:46:34', 'TEST');
INSERT INTO `bookmark` VALUES (7, 7, 7, 0, '2024-04-17 17:31:20', 'user5');

-- ----------------------------
-- Table structure for cake
-- ----------------------------
DROP TABLE IF EXISTS `cake`;
CREATE TABLE `cake`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '糕点名|like',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片|image1',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '描述|rich',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '价格',
  `cate_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '分类ID',
  `del_flag` int(10) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '糕点' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cake
-- ----------------------------
INSERT INTO `cake` VALUES (1, '海绵蛋糕XXO', 'http://localhost:8080/file?path=/upload/1779423446118825984/Snipaste_2024-04-14_16-05-51.png', '<p>1231313132</p>', 13.00, '1', 0, '2024-04-14 16:16:32', 'admin');
INSERT INTO `cake` VALUES (2, '樱花草莓奥利奥慕斯蛋糕', 'http://localhost:8080/file?path=/upload/1779817009830825984/Snipaste_2024-04-15_18-19-51.png', '<p>樱花草莓奥利奥慕斯蛋糕</p><p><br></p><p>樱花草莓奥利奥慕斯蛋糕</p><p><br></p><p>樱花草莓奥利奥慕斯蛋糕</p><p><br></p><p>樱花草莓奥利奥慕斯蛋糕</p><p><br></p><p>樱花草莓奥利奥慕斯蛋糕</p><p><br></p><p>樱花草莓奥利奥慕斯蛋糕樱花草莓奥利奥慕斯蛋糕</p><p><br></p><p><br></p>', 68.00, '2', 0, '2024-04-15 18:20:32', 'admin');
INSERT INTO `cake` VALUES (3, '焦糖海绵蛋糕', 'http://localhost:8080/file?path=/upload/1780108766372134912/Snipaste_2024-04-16_13-39-05.png', '<p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p><br></p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p><p>焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕焦糖海绵蛋糕</p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', 36.00, '1', 0, '2024-04-16 13:39:54', 'admin');
INSERT INTO `cake` VALUES (4, '黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '<p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~</p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', 68.00, '4', 0, '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES (5, '巧克力雪山黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '<p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~</p>黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', 68.00, '4', 0, '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES (6, '草莓布丁黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', 68.00, '4', 0, '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES (7, '香草布丁黑森林蛋糕', 'http://localhost:8080/file?path=/upload/1780109967994093568/Snipaste_2024-04-16_13-44-17.png', '黑森林蛋糕~德国最受欢迎的甜点，它融合了樱桃的酸、奶油的甜、🍫巧克力的苦、🍒樱桃酒的醇香，一口咬下去，咔嚓咔嚓声里都是成粒车厘子，超满足~', 68.00, '4', 0, '2024-04-16 13:44:32', 'admin');
INSERT INTO `cake` VALUES (8, '测试', 'http://localhost:8080/file?path=/upload/1780142347538612224/Snipaste_2024-04-16_15-30-51.png', '<p>森森d发放大森a森森僧稍等僧</p>', 111.00, '1', 1, '2024-04-16 15:53:11', 'admin');
INSERT INTO `cake` VALUES (9, '测试', 'http://localhost:8080/file?path=/upload/1780155032225398784/Snipaste_2024-04-16_15-30-51.png', '<p>as发放撒发s发森</p>', 222.00, '1', 1, '2024-04-16 16:43:36', 'admin');

-- ----------------------------
-- Table structure for cate
-- ----------------------------
DROP TABLE IF EXISTS `cate`;
CREATE TABLE `cate`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '分类名|like',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片|image1',
  `del_flag` int(10) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '糕点分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cate
-- ----------------------------
INSERT INTO `cate` VALUES (1, '海绵', 'http://localhost:8080/file?path=/upload/1779370851140624384/Snipaste_2024-04-14_12-47-12.png', 0, '2024-04-14 12:47:26', 'admin');
INSERT INTO `cate` VALUES (2, '慕斯', 'http://localhost:8080/file?path=/upload/1779425079074619392/Snipaste_2024-04-14_16-22-46.png', 0, '2024-04-14 16:22:55', 'admin');
INSERT INTO `cate` VALUES (3, '提拉米苏', 'http://localhost:8080/file?path=/upload/1780109230039859200/Snipaste_2024-04-16_13-41-20.png', 0, '2024-04-16 13:41:29', 'admin');
INSERT INTO `cate` VALUES (4, '黑森林', 'http://localhost:8080/file?path=/upload/1780109563243757568/Snipaste_2024-04-16_13-42-37.png', 0, '2024-04-16 13:42:48', 'admin');
INSERT INTO `cate` VALUES (5, '玛玛哈哈', 'http://localhost:8080/file?path=/upload/1780142220484755456/Snipaste_2024-04-16_15-30-51.png', 1, '2024-04-16 15:52:35', 'admin');
INSERT INTO `cate` VALUES (6, '测试', 'http://localhost:8080/file?path=/upload/1780154888742453248/Snipaste_2024-04-16_15-30-51.png', 1, '2024-04-16 16:42:55', 'admin');

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_id` bigint(20) NULL DEFAULT NULL COMMENT '评论对象ID',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '评论内容',
  `del_flag` int(10) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人|like',
  `p_id` bigint(20) NULL DEFAULT 0 COMMENT '上级评论ID',
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '评论人用户ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '商品评论' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comments
-- ----------------------------
INSERT INTO `comments` VALUES (2, 1, '123', 1, '2024-04-15 19:47:07', 'user5', 0, 7);
INSERT INTO `comments` VALUES (3, 2, '123333', 1, '2024-04-15 19:47:22', 'user5', 0, 7);
INSERT INTO `comments` VALUES (4, 1, '1231232131232', 1, '2024-04-15 19:57:34', 'user5', 0, 7);
INSERT INTO `comments` VALUES (6, 7, '不怎么好吃~吃', 1, '2024-04-16 16:17:15', 'hahahaha', 0, 11);
INSERT INTO `comments` VALUES (7, 7, '好吃😋', 0, '2024-04-16 16:47:04', 'TEST', 0, 13);
INSERT INTO `comments` VALUES (8, 7, '12345611111', 0, '2024-04-17 17:31:37', 'user5', 0, 7);

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户|snumber',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '内容|like|textarea',
  `reply` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '回复|textarea',
  `feedback_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '精选|eq',
  `del_flag` int(11) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '留言板' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of feedback
-- ----------------------------
INSERT INTO `feedback` VALUES (1, 1, '你好啊', '123', NULL, 1, '2024-03-31 03:10:43', 'user1');
INSERT INTO `feedback` VALUES (2, 1, '啊打发士大夫', '22222222', '精选', 1, '2024-03-31 03:11:43', 'user1');
INSERT INTO `feedback` VALUES (3, 7, '李四啊啊啊', 'OKOKOK', '精选', 1, '2024-03-31 15:42:03', 'user5');
INSERT INTO `feedback` VALUES (4, 7, '123123', NULL, NULL, 1, '2024-04-13 13:55:58', 'user5');
INSERT INTO `feedback` VALUES (5, 7, '12313', '111', NULL, 1, '2024-04-15 18:22:49', 'user5');
INSERT INTO `feedback` VALUES (6, 11, '123', NULL, NULL, 1, '2024-04-16 16:39:28', 'hahahaha');
INSERT INTO `feedback` VALUES (7, 13, '做得很好', NULL, NULL, 0, '2024-04-16 16:47:28', 'TEST');
INSERT INTO `feedback` VALUES (8, 7, '测试评论', NULL, NULL, 0, '2024-04-17 16:53:03', 'user5');
INSERT INTO `feedback` VALUES (9, 7, '测试评论输入~', NULL, NULL, 0, '2024-04-17 17:31:57', 'user5');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '标题|like',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '正文|rich',
  `del_flag` int(11) NULL DEFAULT 0 COMMENT '是否删除',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '公告' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '热烈庆祝我司与著名蛋糕连锁品牌罗森妮娜达成战略合作！！！', '<p class=\"ql-align-center\"><strong class=\"ql-size-large\">热烈庆祝我司与著名蛋糕连锁品牌罗森妮娜达成战略合作！！！</strong></p><p><img src=\"http://localhost:8080/file?path=/upload/1779717172443725824/5dc379ed728061691.jpg_e1080.jpg\"></p><p><br></p><p><br></p><p>	<span style=\"color: rgb(51, 51, 51);\">湖南罗森尼娜食品有限公司于2015年10月27日成立。法定代表人朱满文,公司经营范围包括：糕点、面包、饼干及其他焙烤食品、速冻食品、蔬菜、水果罐头、糖果、巧克力的制造；糕点、面包、咖啡器具的零售；预包装食品、散装食品、水果、乳制品的销售；冷热饮品制售；西餐服务；中餐服务；烘焙食品制造（现场制售）；水果和坚果加工；水果的冷冻冷藏；蜜饯制作；咖啡馆服务等。</span></p>', 0, '2024-04-15 11:44:50', 'admin');
INSERT INTO `notice` VALUES (2, '测送上', '<p>测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上测送上</p>', 1, '2024-04-16 15:53:56', 'admin');
INSERT INTO `notice` VALUES (3, '测试', '<p>测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试</p>', 1, '2024-04-16 16:44:18', 'admin');
INSERT INTO `notice` VALUES (4, '探索蛋糕的营养价值：解析美味与健康的平衡', '<p class=\"ql-align-center\"><strong class=\"ql-size-large\">探索蛋糕的营养价值：解析美味与健康的平衡</strong></p><p class=\"ql-align-center\"><br></p><p>在当今社会，蛋糕不仅仅是一种美味的甜点，更是庆祝生日、婚礼和其他特殊场合的象征。然而，随着人们对健康生活方式的追求，蛋糕的营养价值也成为了备受关注的话题。本文将深入探讨蛋糕的营养成分，揭示美味与健康之间的微妙平衡。</p><p><br></p><p>蛋糕的主要成分通常包括面粉、糖、蛋和黄油。面粉提供了碳水化合物和部分蛋白质，是蛋糕的主要能量来源。糖为蛋糕带来了甜味，但过量摄入可能导致血糖波动和其他健康问题。蛋提供了蛋白质和维生素，而黄油则为蛋糕增添了丰富的口感和口味。</p><p><br></p><p>尽管蛋糕的主要成分带来了美味的享受，但也不能忽视其潜在的营养缺陷。传统蛋糕通常富含糖分和脂肪，摄入过多可能导致肥胖、心血管疾病等健康问题。因此，人们开始寻求更健康的蛋糕替代品，如低糖、低脂或无麸质蛋糕，以满足对美味和健康的双重追求。</p><p><br></p><p>在当前的健康饮食趋势下，蛋糕制造商和烘焙师们也在不断创新，尝试将营养与美味完美融合。他们使用更多的天然食材，如新鲜水果、坚果和全麦面粉，来增加蛋糕的纤维、维生素和矿物质含量。此外，一些蛋糕采用代糖或果泥替代传统糖分，以降低热量和糖分含量，同时保持甜味和口感。</p><p><br></p><p>在选择蛋糕时，消费者应该更加关注其营养成分表和食材清单。选择含有更多天然食材、少糖少脂的蛋糕，可以在享受美味的同时，保持健康的饮食习惯。此外，适量食用蛋糕，结合均衡的饮食和健康的生活方式，才是保持身体健康的关键。</p><p><br></p><p>因此，蛋糕的营养分析不仅仅是了解其成分，更是在美味与健康之间找到平衡的关键。通过选择更健康的蛋糕替代品，我们可以享受美味的同时，也保持身体的健康。让我们一起探索蛋糕的美味与营养，追求健康生活的甜蜜滋味。</p>', 0, '2024-04-17 15:17:49', 'admin');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户ID',
  `cake_id` bigint(20) NULL DEFAULT NULL COMMENT '糕点ID',
  `cake_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '糕点名|like',
  `cate_id` bigint(20) NULL DEFAULT NULL COMMENT '糕点分类ID',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '单价',
  `quantity` int(10) NULL DEFAULT NULL COMMENT '数量',
  `cost` decimal(10, 2) NULL DEFAULT NULL COMMENT '订单金额',
  `sn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '订单编号',
  `del_flag` int(10) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '订单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1, 7, 2, '樱花草莓奥利奥慕斯蛋糕', 2, 68.00, 11, 748.00, '202404151840252260001', 0, '2024-04-15 18:40:25', 'user5');
INSERT INTO `orders` VALUES (2, 7, 1, '海绵蛋糕XXO', 1, 13.00, 2, 26.00, '202404151840415590002', 0, '2024-04-15 18:40:42', 'user5');
INSERT INTO `orders` VALUES (3, 5, 2, '樱花草莓奥利奥慕斯蛋糕', 2, 68.00, 12, 816.00, '202404161213572190001', 0, '2024-04-16 12:13:58', 'user4');
INSERT INTO `orders` VALUES (4, 8, 1, '海绵蛋糕XXO', 1, 13.00, 1, 13.00, '202404161239376240002', 0, '2024-04-16 12:39:38', 'user6');
INSERT INTO `orders` VALUES (5, 8, 4, '黑森林蛋糕', 4, 68.00, 5, 340.00, '202404161345237420001', 0, '2024-04-16 13:45:24', 'user6');
INSERT INTO `orders` VALUES (6, 3, 5, '巧克力雪山黑森林蛋糕', 4, 68.00, 6, 408.00, '202404161513116730002', 0, '2024-04-16 15:13:11', 'user2');
INSERT INTO `orders` VALUES (7, 3, 6, '草莓布丁黑森林蛋糕', 4, 68.00, 5, 340.00, '202404161513221930003', 0, '2024-04-16 15:13:22', 'user2');
INSERT INTO `orders` VALUES (8, 3, 7, '香草布丁黑森林蛋糕', 4, 68.00, 7, 476.00, '202404161513296070004', 0, '2024-04-16 15:13:30', 'user2');
INSERT INTO `orders` VALUES (9, 3, 3, '焦糖海绵蛋糕', 1, 36.00, 9, 324.00, '202404161514175430005', 0, '2024-04-16 15:14:18', 'user2');
INSERT INTO `orders` VALUES (10, 3, 1, '海绵蛋糕XXO', 1, 13.00, 12, 156.00, '202404161514468150006', 0, '2024-04-16 15:14:47', 'user2');
INSERT INTO `orders` VALUES (11, 11, 7, '香草布丁黑森林蛋糕', 4, 68.00, 12, 816.00, '202404161616459920001', 1, '2024-04-16 16:16:45', 'hahahaha');
INSERT INTO `orders` VALUES (12, 13, 7, '香草布丁黑森林蛋糕', 4, 68.00, 2, 136.00, '202404161646504110002', 0, '2024-04-16 16:46:50', 'TEST');
INSERT INTO `orders` VALUES (13, 7, 7, '香草布丁黑森林蛋糕', 4, 68.00, 12, 816.00, '202404171731258390001', 0, '2024-04-17 17:31:26', 'user5');

-- ----------------------------
-- Table structure for registration
-- ----------------------------
DROP TABLE IF EXISTS `registration`;
CREATE TABLE `registration`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `activity_id` bigint(20) NULL DEFAULT NULL COMMENT '活动|snumber',
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '报名用户|snumber',
  `del_flag` int(11) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '活动报名' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of registration
-- ----------------------------
INSERT INTO `registration` VALUES (2, 2, 1, 0, '2024-03-31 04:34:22', 'user1');
INSERT INTO `registration` VALUES (3, 3, 7, 0, '2024-03-31 15:45:12', 'user5');
INSERT INTO `registration` VALUES (4, 3, 5, 0, '2024-03-31 15:45:24', 'user4');

-- ----------------------------
-- Table structure for sensitive_word
-- ----------------------------
DROP TABLE IF EXISTS `sensitive_word`;
CREATE TABLE `sensitive_word`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `word` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '敏感词|like',
  `del_flag` int(11) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '敏感词' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sensitive_word
-- ----------------------------
INSERT INTO `sensitive_word` VALUES (1, '测试', 0, '2024-03-31 01:19:38', 'admin');
INSERT INTO `sensitive_word` VALUES (2, '敏', 0, '2024-03-31 01:19:45', 'admin');
INSERT INTO `sensitive_word` VALUES (3, '饿', 0, '2024-03-31 01:19:50', 'admin');
INSERT INTO `sensitive_word` VALUES (4, '123456', 1, '2024-03-31 15:40:26', 'admin');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '类型|select|eq',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户名|like',
  `pwd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '密码|password',
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '姓名|like',
  `sex` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '性别|select|eq',
  `age` int(11) NULL DEFAULT NULL COMMENT '年龄|number',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '手机号|like',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '头像|image1',
  `del_flag` int(11) NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, '管理员', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '测试', '男', 22, '16655554444', 'http://localhost:8080/file?path=/upload/1780155494374785024/Snipaste_2024-04-16_15-30-51.png', 0, '2024-03-30 19:44:33', 'admin');
INSERT INTO `sys_user` VALUES (2, '管理员', 'admin2', 'e10adc3949ba59abbe56e057f20f883e', '管111', '男', 22, '16655554444', 'http://localhost:8080/file?path=/upload/1774340287986700288/9.jpg', 0, '2024-03-30 19:44:33', 'admin');
INSERT INTO `sys_user` VALUES (3, '用户', 'user2', 'e10adc3949ba59abbe56e057f20f883e', 'user2', '男', 22, '15588885555', 'http://localhost:8080/file?path=/upload/1774045535139581952/3.jpg', 0, '2024-03-30 20:06:31', 'admin');
INSERT INTO `sys_user` VALUES (4, '用户', 'user3', 'e10adc3949ba59abbe56e057f20f883e', 'user3', '女', 21, '15544441111', 'http://localhost:8080/file?path=/upload/1774045840057163776/4.jpg', 0, '2024-03-30 20:07:44', 'admin');
INSERT INTO `sys_user` VALUES (5, '管理员', 'admin5', 'e10adc3949ba59abbe56e057f20f883e', '管111', '男', 22, '16655554444', 'http://localhost:8080/file?path=/upload/1774340287986700288/9.jpg', 0, '2024-03-30 19:44:33', 'admin');
INSERT INTO `sys_user` VALUES (6, '用户', '1', 'bea43f5f7ad39e2d184cb16885043d42', '1', '男', 11, '12311111111', 'http://localhost:8080/file?path=/upload/1774340632657825792/4.jpg', 1, '2024-03-31 15:39:08', 'admin');
INSERT INTO `sys_user` VALUES (7, '用户', 'user5', 'e10adc3949ba59abbe56e057f20f883e', '李四', '男', 22, '13555555555', 'http://localhost:8080/file?path=/upload/1774341128244203520/5.jpg', 0, '2024-03-31 15:41:06', '注册');
INSERT INTO `sys_user` VALUES (8, '用户', 'user6', 'e10adc3949ba59abbe56e057f20f883e', 'test', '男', 22, '13012345678', 'http://localhost:8080/file?path=/upload/1780141927961411584/Snipaste_2024-04-16_15-30-36.png', 0, '2024-04-16 12:38:26', 'admin');
INSERT INTO `sys_user` VALUES (9, '用户', 'user9', 'e10adc3949ba59abbe56e057f20f883e', 'user9', '男', 12, '18612345678', 'http://localhost:8080/file?path=/upload/1780137682264621056/Snipaste_2024-04-16_15-30-51.png', 1, '2024-04-16 15:34:33', 'admin');
INSERT INTO `sys_user` VALUES (10, '用户', 'test', 'e10adc3949ba59abbe56e057f20f883e', 'test', '女', 13, '13012345678', 'http://localhost:8080/file?path=/upload/1780143898734837760/Snipaste_2024-04-16_15-30-51.png', 1, '2024-04-16 15:59:15', 'admin');
INSERT INTO `sys_user` VALUES (11, '用户', 'hahahaha', 'e10adc3949ba59abbe56e057f20f883e', 'haha', '男', 21, '13012345678', 'http://localhost:8080/file?path=/upload/1780148182213935104/Snipaste_2024-04-16_15-30-51.png', 1, '2024-04-16 16:16:16', '注册');
INSERT INTO `sys_user` VALUES (12, '用户', 'hahaha1', 'e10adc3949ba59abbe56e057f20f883e', 'hahaha', '男', 21, '13012345678', 'http://localhost:8080/file?path=/upload/1780154745662160896/Snipaste_2024-04-16_15-30-36.png', 1, '2024-04-16 16:42:10', 'admin');
INSERT INTO `sys_user` VALUES (13, '用户', 'TEST', 'e10adc3949ba59abbe56e057f20f883e', 'TEST', '男', 21, '13012345678', 'http://localhost:8080/file?path=/upload/1780155756573310976/Snipaste_2024-04-16_15-30-51.png', 0, '2024-04-16 16:46:22', '注册');

SET FOREIGN_KEY_CHECKS = 1;
