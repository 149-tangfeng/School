package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Cake;
import com.example.project.entity.Cate;
import com.example.project.entity.Options;
import com.example.project.service.CakeService;
import com.example.project.service.CateService;
import com.example.project.util.ObjectUtil;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 蛋糕
 */
@Slf4j
@RestController
public class CakeController {

    @Autowired
    private CakeService cakeService;
    @Autowired
    private CateService cateService;

    // 分页
    @PostMapping("/api/cake/page")
    public R page(@RequestBody Cake cake) {
        LambdaQueryWrapper<Cake> qw = new LambdaQueryWrapper<>();
        qw.eq(ObjectUtil.isNotEmpty(cake.getCateId()), Cake::getCateId, cake.getCateId());
        qw.eq(Cake::getDelFlag, 0);
        qw.like(ObjectUtil.isNotEmpty(cake.getName()), Cake::getName, cake.getName());
        qw.orderByDesc(Cake::getId);
        Page<Cake> page = cakeService.page(
                new Page<>(cake.getPageNum(), cake.getPageSize()),
                qw
        );
        page.getRecords().forEach(item -> {
            LambdaQueryWrapper<Cate> categoryQw = new LambdaQueryWrapper<>();
            categoryQw.eq(Cate::getId, item.getCateId());
            Cate cate = cateService.getById(item.getCateId());
            item.setCate(cate);
        });
        return R.ok(new PageVO(page.getTotal(), page.getRecords()));
    }

    // 列表
    @PostMapping("/api/cake/list")
    public R list(@RequestBody Cake cake) {
        LambdaQueryWrapper<Cake> qw = new LambdaQueryWrapper<>();
        qw.eq(Cake::getDelFlag, 0);
        qw.orderByDesc(Cake::getId);
        List<Cake> list = cakeService.list(qw);
        return R.ok(list);
    }

    // 添加
    @PostMapping("/api/cake/add")
    public R add(@RequestBody Cake cake) {
        cake.setCreateBy(StpUtil.getSession().getString("username"));
        cake.setCreateTime(new Date());
        cakeService.save(cake);
        return R.ok();
    }

    // 修改
    @PostMapping("/api/cake/update")
    public R update(@RequestBody Cake cake) {
        cakeService.updateById(cake);
        return R.ok();
    }

    // 删除
    @PostMapping("/api/cake/delete")
    public R delete(@RequestBody Cake cake) {
        LambdaQueryWrapper<Cake> qw = new LambdaQueryWrapper<>();
        qw.in(Cake::getId, cake.getIds());
        cake.setDelFlag(1);
        cakeService.update(cake, qw);
        return R.ok();
    }

    // 详情
    @PostMapping("/api/cake/detail")
    public R detail(@RequestBody Cake cake) {
        Cake entity = cakeService.getById(cake.getId());
        return R.ok(entity);
    }

    //下拉列表
    @PostMapping("/api/cake/options")
    public R options() {
        LambdaQueryWrapper<Cake> qw = new LambdaQueryWrapper<>();
        qw.eq(Cake::getDelFlag, 0);
        List<Cake> cakeList = cakeService.list(qw);
        List<Options> list = cakeList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉");
            options.setValue(item.getId());
            return options;
        }).toList();
        return R.ok(list);
    }
}