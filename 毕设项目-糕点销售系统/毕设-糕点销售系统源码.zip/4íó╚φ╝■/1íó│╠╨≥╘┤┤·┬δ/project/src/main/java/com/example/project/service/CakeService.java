package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Cake;
import com.example.project.mapper.CakeMapper;
import org.springframework.stereotype.Service;

/**
 * 蛋糕
 */
@Service
public class CakeService extends ServiceImpl<CakeMapper, Cake> {

}
