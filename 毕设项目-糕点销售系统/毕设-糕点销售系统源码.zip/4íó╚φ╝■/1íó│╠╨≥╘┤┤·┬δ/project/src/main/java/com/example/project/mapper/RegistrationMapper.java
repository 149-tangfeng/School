package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Registration;
import org.apache.ibatis.annotations.Mapper;

/**
 * 活动报名
 */
@Mapper
public interface RegistrationMapper extends BaseMapper<Registration> {

}