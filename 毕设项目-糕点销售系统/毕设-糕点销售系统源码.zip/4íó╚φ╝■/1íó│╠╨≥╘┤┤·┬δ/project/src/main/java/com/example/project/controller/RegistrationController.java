package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Options;
import com.example.project.entity.Registration;
import com.example.project.service.RegistrationService;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 活动报名管理控制器，处理活动报名相关的请求
 */
@Slf4j
@RestController
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService; // 活动报名服务

    // 分页查询活动报名列表
    @PostMapping("/api/registration/page")
    public R page(@RequestBody Registration registration) {
        LambdaQueryWrapper<Registration> qw = new LambdaQueryWrapper<>();
        qw.eq(Registration::getDelFlag, 0); // 查询未删除的活动报名记录
        qw.orderByDesc(Registration::getId); // 按照ID倒序排列
        // 分页查询活动报名列表并返回分页结果
        Page<Registration> page = registrationService.page(
                new Page<>(registration.getPageNum(), registration.getPageSize()), qw);
        return R.ok(new PageVO(page.getTotal(), page.getRecords())); // 返回分页结果
    }

    // 查询活动报名列表
    @PostMapping("/api/registration/list")
    public R list(@RequestBody Registration registration) {
        LambdaQueryWrapper<Registration> qw = new LambdaQueryWrapper<>();
        qw.eq(Registration::getDelFlag, 0); // 查询未删除的活动报名记录
        qw.orderByDesc(Registration::getId); // 按照ID倒序排列
        List<Registration> list = registrationService.list(qw);
        return R.ok(list); // 返回查询结果列表
    }

    // 添加活动报名记录
    @PostMapping("/api/registration/add")
    public R add(@RequestBody Registration registration) {
        LambdaQueryWrapper<Registration> qw = new LambdaQueryWrapper<>();
        qw.eq(Registration::getUserId, StpUtil.getLoginIdAsLong()); // 查询当前用户是否已报名该活动
        qw.eq(Registration::getActivityId, registration.getActivityId());
        long count = registrationService.count(qw);
        if (count > 0) {
            return R.error("已报名该活动，不要重复操作");
        }
        registration.setUserId(StpUtil.getLoginIdAsLong()); // 设置报名用户ID为当前登录用户
        registration.setCreateBy(StpUtil.getSession().getString("username")); // 设置创建者
        registration.setCreateTime(new Date()); // 设置创建时间为当前时间
        registrationService.save(registration); // 保存活动报名记录
        return R.ok(); // 返回成功响应
    }

    // 修改活动报名记录
    @PostMapping("/api/registration/update")
    public R update(@RequestBody Registration registration) {
        registrationService.updateById(registration); // 根据ID更新活动报名记录
        return R.ok(); // 返回成功响应
    }

    // 删除活动报名记录
    @PostMapping("/api/registration/delete")
    public R delete(@RequestBody Registration registration) {
        LambdaQueryWrapper<Registration> qw = new LambdaQueryWrapper<>();
        qw.in(Registration::getId, registration.getIds()); // 根据ID列表删除活动报名记录
        registration.setDelFlag(1); // 标记为已删除
        registrationService.update(registration, qw); // 批量更新活动报名记录
        return R.ok(); // 返回成功响应
    }

    // 查询活动报名详情
    @PostMapping("/api/registration/detail")
    public R detail(@RequestBody Registration registration) {
        Registration entity = registrationService.getById(registration.getId()); // 根据ID查询活动报名详情
        return R.ok(entity); // 返回活动报名详情
    }

    // 查询活动报名下拉列表
    @PostMapping("/api/registration/options")
    public R options() {
        LambdaQueryWrapper<Registration> qw = new LambdaQueryWrapper<>();
        qw.eq(Registration::getDelFlag, 0); // 查询未删除的活动报名记录
        List<Registration> registrationList = registrationService.list(qw);
        // 构建下拉列表选项
        List<Options> list = registrationList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉"); // 设置选项显示文本
            options.setValue(item.getId()); // 设置选项值
            return options;
        }).toList();
        return R.ok(list); // 返回活动报名下拉列表
    }
}
