package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.SysUser;
import com.example.project.mapper.SysUserMapper;
import org.springframework.stereotype.Service;

/**
 * 用户
 */
@Service
public class SysUserService extends ServiceImpl<SysUserMapper, SysUser> {

}
