package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Comments;
import com.example.project.entity.Options;
import com.example.project.service.CommentsService;
import com.example.project.service.SysUserService;
import com.example.project.util.ObjectUtil;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 商品评论
 */
@Slf4j
@RestController
public class CommentsController {

    @Autowired
    private CommentsService commentsService;
    @Autowired
    private SysUserService sysUserService;

    // 分页
    @PostMapping("/api/comments/page")
    public R page(@RequestBody Comments comments) {
        LambdaQueryWrapper<Comments> qw = new LambdaQueryWrapper<>();
        qw.eq(Comments::getDelFlag, 0);
        qw.eq(ObjectUtil.isNotEmpty(comments.getDataId()), Comments::getDataId, comments.getDataId());
        qw.orderByDesc(Comments::getId);
        Page<Comments> page = commentsService.page(
                new Page<>(comments.getPageNum(), comments.getPageSize()),
                qw
        );
        page.getRecords().forEach(item -> {
            item.setUser(sysUserService.getById(item.getUserId()));
        });
        return R.ok(new PageVO(page.getTotal(), page.getRecords()));
    }

    // 列表
    @PostMapping("/api/comments/list")
    public R list(@RequestBody Comments comments) {
        LambdaQueryWrapper<Comments> qw = new LambdaQueryWrapper<>();
        qw.eq(Comments::getDelFlag, 0);
        qw.orderByDesc(Comments::getId);
        List<Comments> list = commentsService.list(qw);
        return R.ok(list);
    }

    // 添加
    @PostMapping("/api/comments/add")
    public R add(@RequestBody Comments comments) {
        comments.setCreateBy(StpUtil.getSession().getString("username"));
        comments.setCreateTime(new Date());
        commentsService.save(comments);
        return R.ok();
    }

    // 修改
    @PostMapping("/api/comments/update")
    public R update(@RequestBody Comments comments) {
        commentsService.updateById(comments);
        return R.ok();
    }

    // 删除
    @PostMapping("/api/comments/delete")
    public R delete(@RequestBody Comments comments) {
        LambdaQueryWrapper<Comments> qw = new LambdaQueryWrapper<>();
        qw.in(Comments::getId, comments.getIds());
        comments.setDelFlag(1);
        commentsService.update(comments, qw);
        return R.ok();
    }

    // 详情
    @PostMapping("/api/comments/detail")
    public R detail(@RequestBody Comments comments) {
        Comments entity = commentsService.getById(comments.getId());
        return R.ok(entity);
    }

    //下拉列表
    @PostMapping("/api/comments/options")
    public R options() {
        LambdaQueryWrapper<Comments> qw = new LambdaQueryWrapper<>();
        qw.eq(Comments::getDelFlag, 0);
        List<Comments> commentsList = commentsService.list(qw);
        List<Options> list = commentsList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉");
            options.setValue(item.getId());
            return options;
        }).toList();
        return R.ok(list);
    }
}