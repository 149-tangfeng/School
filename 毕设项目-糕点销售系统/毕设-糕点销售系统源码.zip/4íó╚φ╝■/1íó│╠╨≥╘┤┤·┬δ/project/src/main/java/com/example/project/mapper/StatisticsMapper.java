package com.example.project.mapper;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Statistics;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface StatisticsMapper extends BaseMapper<Statistics> {

    Statistics selectCountInfo(DateTime beginOfDay);
}