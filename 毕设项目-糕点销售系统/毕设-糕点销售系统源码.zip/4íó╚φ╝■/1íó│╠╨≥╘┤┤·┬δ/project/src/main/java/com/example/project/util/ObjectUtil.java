package com.example.project.util;

import cn.hutool.core.util.StrUtil;

import java.util.Objects;

public class ObjectUtil {

    public static boolean isNotEmpty(Object obj) {
        if (obj instanceof String) {
            return StrUtil.isNotBlank((CharSequence) obj);
        }
        return !Objects.isNull(obj);
    }
}
