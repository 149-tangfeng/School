package com.example.project.entity;

import cn.hutool.core.lang.Dict;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 蛋糕
 */
@Data
@TableName("cake")
public class Cake implements Serializable {
    //
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    //蛋糕名
    private String name;
    //图片
    private String img;
    //描述
    private String content;
    //价格
    private BigDecimal price;
    //分类ID
    private String cateId;
    //
    private Integer delFlag;
    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    //创建人
    private String createBy;

    // ==============================
    @TableField(exist = false)
    private Dict ext = Dict.create();
    //页码，从1开始
    @TableField(exist = false)
    private Integer pageNum;
    //每页查询数
    @TableField(exist = false)
    private Integer pageSize;
    @TableField(exist = false)
    private List<Long> ids;

    @TableField(exist = false)
    private Cate cate;
}
