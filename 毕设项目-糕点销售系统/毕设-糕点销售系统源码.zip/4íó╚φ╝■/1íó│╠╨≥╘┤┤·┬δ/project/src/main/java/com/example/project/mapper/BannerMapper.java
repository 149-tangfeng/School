package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Banner;
import org.apache.ibatis.annotations.Mapper;

/**
 * 轮播图
 */
@Mapper
public interface BannerMapper extends BaseMapper<Banner> {

}