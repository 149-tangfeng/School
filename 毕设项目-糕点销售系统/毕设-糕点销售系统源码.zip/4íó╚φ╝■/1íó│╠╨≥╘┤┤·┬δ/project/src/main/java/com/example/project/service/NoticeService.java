package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Notice;
import com.example.project.mapper.NoticeMapper;
import org.springframework.stereotype.Service;

/**
 * 公告
 */
@Service
public class NoticeService extends ServiceImpl<NoticeMapper, Notice> {

}
