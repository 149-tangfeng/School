package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Cake;
import com.example.project.entity.Options;
import com.example.project.entity.Orders;
import com.example.project.service.CakeService;
import com.example.project.service.OrdersService;
import com.example.project.util.ObjectUtil;
import com.example.project.util.OrderNumberGenerator;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 订单
 */
@Slf4j
@RestController
public class OrdersController {

    @Autowired
    private OrdersService ordersService;
    @Autowired
    private CakeService cakeService;

    // 分页
    @PostMapping("/api/orders/page")
    public R page(@RequestBody Orders orders) {
        LambdaQueryWrapper<Orders> qw = new LambdaQueryWrapper<>();
        qw.eq(Orders::getDelFlag, 0);
        qw.like(ObjectUtil.isNotEmpty(orders.getCakeName()), Orders::getCakeName, orders.getCakeName());
        qw.eq(orders.getUserId() != null, Orders::getUserId, orders.getUserId());
        qw.orderByDesc(Orders::getId);
        Page<Orders> page = ordersService.page(
                new Page<>(orders.getPageNum(), orders.getPageSize()),
                qw
        );
        page.getRecords().forEach(item -> {
            LambdaQueryWrapper<Cake> cakeqw = new LambdaQueryWrapper<>();
            cakeqw.eq(Cake::getId, item.getCakeId());
            Cake cake = cakeService.getOne(cakeqw);
            item.setCake(cake);
        });
        return R.ok(new PageVO(page.getTotal(), page.getRecords()));
    }

    // 列表
    @PostMapping("/api/orders/list")
    public R list(@RequestBody Orders orders) {
        LambdaQueryWrapper<Orders> qw = new LambdaQueryWrapper<>();
        qw.eq(Orders::getDelFlag, 0);
        qw.orderByDesc(Orders::getId);
        List<Orders> list = ordersService.list(qw);
        return R.ok(list);
    }

    // 添加
    @PostMapping("/api/orders/add")
    public R add(@RequestBody Orders orders) {
        orders.setCreateBy(StpUtil.getSession().getString("username"));
        orders.setCreateTime(new Date());

        String s = OrderNumberGenerator.generateOrderNumber();
        orders.setSn(s);
        ordersService.save(orders);
        return R.ok();
    }

    // 修改
    @PostMapping("/api/orders/update")
    public R update(@RequestBody Orders orders) {
        ordersService.updateById(orders);
        return R.ok();
    }

    // 删除
    @PostMapping("/api/orders/delete")
    public R delete(@RequestBody Orders orders) {
        LambdaQueryWrapper<Orders> qw = new LambdaQueryWrapper<>();
        qw.in(Orders::getId, orders.getIds());
        orders.setDelFlag(1);
        ordersService.update(orders, qw);
        return R.ok();
    }

    // 详情
    @PostMapping("/api/orders/detail")
    public R detail(@RequestBody Orders orders) {
        Orders entity = ordersService.getById(orders.getId());
        return R.ok(entity);
    }

    //下拉列表
    @PostMapping("/api/orders/options")
    public R options() {
        LambdaQueryWrapper<Orders> qw = new LambdaQueryWrapper<>();
        qw.eq(Orders::getDelFlag, 0);
        List<Orders> ordersList = ordersService.list(qw);
        List<Options> list = ordersList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉");
            options.setValue(item.getId());
            return options;
        }).toList();
        return R.ok(list);
    }
}