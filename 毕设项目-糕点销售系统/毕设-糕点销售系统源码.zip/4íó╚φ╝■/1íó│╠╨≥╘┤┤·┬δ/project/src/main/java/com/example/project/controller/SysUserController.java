package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Options;
import com.example.project.entity.SysUser;
import com.example.project.service.SysUserService;
import com.example.project.util.MD5Util;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@Slf4j
@RestController
public class SysUserController {

    @Autowired
    private SysUserService sysUserService; // 自动注入用户服务

    // 分页查询用户列表
    @PostMapping("/api/sysUser/page")
    public R page(@RequestBody SysUser sysUser) {
        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
        qw.eq(SysUser::getDelFlag, 0); // 查询未删除的用户
        // 设置查询条件
        qw.eq(StrUtil.isNotBlank(sysUser.getSex()), SysUser::getSex, sysUser.getSex()); // 按性别查询
        qw.ne(SysUser::getUserType, "管理员"); // 排除管理员用户
        qw.eq(StrUtil.isNotBlank(sysUser.getUserType()), SysUser::getUserType, sysUser.getUserType()); // 按用户类型查询
        qw.like(StrUtil.isNotBlank(sysUser.getUsername()), SysUser::getUsername, sysUser.getUsername()); // 模糊匹配用户名
        qw.like(StrUtil.isNotBlank(sysUser.getDisplayName()), SysUser::getDisplayName, sysUser.getDisplayName()); // 模糊匹配显示名
        qw.like(StrUtil.isNotBlank(sysUser.getPhone()), SysUser::getPhone, sysUser.getPhone()); // 模糊匹配手机号
        qw.orderByDesc(SysUser::getId); // 按照ID倒序排列
        // 分页查询用户列表并返回分页结果
        Page<SysUser> page = sysUserService.page(
                new Page<>(sysUser.getPageNum(), sysUser.getPageSize()), qw);
        return R.ok(new PageVO(page.getTotal(), page.getRecords())); // 返回分页结果
    }

    // 添加用户
    @PostMapping("/api/sysUser/add")
    public R add(@RequestBody SysUser sysUser) {
        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
        qw.eq(SysUser::getUsername, sysUser.getUsername()); // 查询用户名是否已存在
        long count = sysUserService.count(qw);
        // 判断用户名是否已存在
        if (count > 0) {
            return R.error("用户名已存在");
        }
        // 设置创建人、密码加密、创建时间，保存用户信息
        sysUser.setUserType("用户"); // 设置用户类型为普通用户
        sysUser.setCreateBy(StpUtil.getSession().getString("username")); // 设置创建者
        sysUser.setPwd(MD5Util.encrypt(sysUser.getPwd())); // 对密码进行加密
        sysUser.setCreateTime(new Date()); // 设置创建时间为当前时间
        sysUserService.save(sysUser); // 保存用户信息
        return R.ok(); // 返回成功响应
    }

    // 修改用户信息
    @PostMapping("/api/sysUser/update")
    public R update(@RequestBody SysUser sysUser) {
        sysUserService.updateById(sysUser); // 根据ID更新用户信息
        return R.ok(); // 返回成功响应
    }

    // 删除用户
    @PostMapping("/api/sysUser/delete")
    public R delete(@RequestBody SysUser sysUser) {
        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
        qw.in(SysUser::getId, sysUser.getIds()); // 根据ID列表删除用户
        sysUser.setDelFlag(1); // 标记为已删除
        sysUserService.update(sysUser, qw); // 批量更新用户信息
        return R.ok(); // 返回成功响应
    }

    // 查询用户详情
    @PostMapping("/api/sysUser/detail")
    public R detail(@RequestBody SysUser sysUser) {
        SysUser entity = sysUserService.getById(sysUser.getId()); // 根据ID查询用户详情
        return R.ok(entity); // 返回用户详情
    }

    // 查询用户下拉列表
    @PostMapping("/api/sysUser/options")
    public R options() {
        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
        qw.eq(SysUser::getDelFlag, 0); // 查询未删除的用户
        List<SysUser> sysUserList = sysUserService.list(qw);
        // 构建下拉列表选项
        List<Options> list = sysUserList.stream().map(item -> {
            Options options = new Options();
            options.setLabel(item.getDisplayName()); // 设置选项显示文本为显示名
            options.setValue(item.getId()); // 设置选项值为用户ID
            return options;
        }).toList();
        return R.ok(list); // 返回用户下拉列表
    }

    // 重置用户密码
    @PostMapping("/api/sysUser/updatepwd")
    public R updatepwd(@RequestBody SysUser sysUser) {
        sysUser.setPwd(MD5Util.encrypt(sysUser.getPwd())); // 对密码进行加密
        sysUserService.updateById(sysUser); // 更新用户密码
        return R.ok(); // 返回成功响应
    }
}

