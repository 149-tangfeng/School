package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.project.entity.SysUser;
import com.example.project.service.SysUserService;
import com.example.project.util.MD5Util;
import com.example.project.util.R;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.Date;

@Slf4j
@RestController
public class ProjectController {

    @Autowired
    private SysUserService sysUserService;
    @Autowired
    private HttpServletResponse response;

    // 退出登录
    @PostMapping("/api/logout")
    public R logout() {
        StpUtil.logout();  // Sa-Token 的注销方法
        return R.ok();  // 返回成功响应
    }

    // 修改密码
    @PostMapping("/api/updatePwd")
    public R updatePwd(@RequestBody SysUser sysUser) {
        // 获取输入的旧密码和新密码
        String oldpwd = sysUser.getOldpwd();
        String newpwd = sysUser.getNewpwd();
        // 根据当前登录用户ID查询用户信息
        SysUser user = sysUserService.getById(StpUtil.getLoginIdAsLong());
        // 判断旧密码是否正确
        if (!user.getPwd().equals(MD5Util.encrypt(oldpwd))) {
            return R.error("旧密码不正确");
        }
        // 更新密码为新密码并保存
        user.setPwd(MD5Util.encrypt(newpwd));
        sysUserService.updateById(user);
        return R.ok();  // 返回成功响应
    }

    // 登录接口
    @PostMapping("/login")
    public R login(@RequestBody SysUser sysUser) {
        // 根据用户名和密码查询用户信息
        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
        qw.eq(SysUser::getDelFlag, 0);
        qw.eq(SysUser::getUsername, sysUser.getUsername());
        qw.eq(SysUser::getPwd, MD5Util.encrypt(sysUser.getPwd()));
        SysUser user = sysUserService.getOne(qw);
        // 判断用户是否存在
        if (user == null) {
            return R.error("账号或密码不正确");
        }
        // 登录成功，设置用户信息到会话中，并返回用户信息
        StpUtil.login(user.getId());
        StpUtil.getSession().set("userType", user.getUserType());
        StpUtil.getSession().set("username", user.getUsername());
        StpUtil.getSession().set("isAdmin", user.getUserType().equals("管理员") ? 1 : 0);
        user.setToken(StpUtil.getTokenValue());
        return R.ok(user);
    }

    // 上传文件接口
    @PostMapping("/upload")
    public R uploadFile(@RequestParam MultipartFile file) {
        if (file.isEmpty()) {
            return R.error("参数错误");
        }
        // 获取上传文件信息并保存到指定目录
        String dir = System.getProperty("user.dir") + "/upload";
        String originalFilename = file.getOriginalFilename();
        String path = StrUtil.format("{}/{}/{}", dir, IdUtil.getSnowflakeNextIdStr(), originalFilename);
        File newFile = new File(path);
        newFile.mkdirs();
        try {
            file.transferTo(newFile);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            return R.error("上传失败");
        }
        // 返回上传成功的文件信息
        return R.ok(Dict.create()
                .set("name", file.getOriginalFilename())
                .set("url", "http://localhost:8080/file?path=" + path.replace(dir, "/upload")));
    }

    //获取文件接口
    @SneakyThrows
    @GetMapping("/file")
    public void file(String path) {
        File file = new File(System.getProperty("user.dir") + path);
        if (file.exists()) {
            response.getOutputStream().write(FileUtil.readBytes(file));
        }
    }

    //注册接口
    @PostMapping("/reg")
    public R reg(@RequestBody SysUser sysUser) {
        // 根据用户名查询用户数量
        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
        qw.eq(SysUser::getDelFlag, 0);
        qw.eq(SysUser::getUsername, sysUser.getUsername());
        long count = sysUserService.count(qw);
        // 判断用户名是否已存在
        if (count > 0) {
            return R.error("用户名已存在");
        }
        // 设置密码加密并保存用户信息
        sysUser.setPwd(MD5Util.encrypt(sysUser.getPwd()));
        sysUser.setCreateTime(new Date());
        sysUser.setCreateBy("注册");
        sysUserService.save(sysUser);
        return R.ok();  // 返回注册成功响应
    }
}
