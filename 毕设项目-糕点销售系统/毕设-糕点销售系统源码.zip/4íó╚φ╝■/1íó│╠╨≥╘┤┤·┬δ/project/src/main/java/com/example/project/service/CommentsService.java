package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Comments;
import com.example.project.mapper.CommentsMapper;
import org.springframework.stereotype.Service;

/**
 * 商品评论
 */
@Service
public class CommentsService extends ServiceImpl<CommentsMapper, Comments> {

}
