package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Cate;
import com.example.project.mapper.CateMapper;
import org.springframework.stereotype.Service;

/**
 * 蛋糕分类
 */
@Service
public class CateService extends ServiceImpl<CateMapper, Cate> {

}
