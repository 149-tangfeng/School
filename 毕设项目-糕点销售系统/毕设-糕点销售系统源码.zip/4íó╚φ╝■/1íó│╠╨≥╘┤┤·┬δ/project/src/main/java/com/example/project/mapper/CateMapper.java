package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Cate;
import org.apache.ibatis.annotations.Mapper;

/**
 * 蛋糕分类
 */
@Mapper
public interface CateMapper extends BaseMapper<Cate> {

}