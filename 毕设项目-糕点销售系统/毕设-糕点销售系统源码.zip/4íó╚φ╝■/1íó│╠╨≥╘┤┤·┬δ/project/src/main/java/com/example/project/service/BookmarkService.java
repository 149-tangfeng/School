package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Bookmark;
import com.example.project.mapper.BookmarkMapper;
import org.springframework.stereotype.Service;

/**
 * 收藏
 */
@Service
public class BookmarkService extends ServiceImpl<BookmarkMapper, Bookmark> {

}
