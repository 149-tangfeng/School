package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Bookmark;
import com.example.project.entity.Cake;
import com.example.project.entity.Cate;
import com.example.project.entity.Options;
import com.example.project.service.BookmarkService;
import com.example.project.service.CakeService;
import com.example.project.service.CateService;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 收藏相关接口控制器，处理收藏相关请求
 */
@Slf4j
@RestController
public class BookmarkController {

    @Autowired
    private BookmarkService bookmarkService;  // 注入收藏服务
    @Autowired
    private CakeService cakeService;  // 注入蛋糕服务
    @Autowired
    private CateService cateService;  // 注入分类服务;

    // 分页查询收藏列表
    @PostMapping("/api/bookmark/page")
    public R page(@RequestBody Bookmark bookmark) {
        LambdaQueryWrapper<Bookmark> qw = new LambdaQueryWrapper<>();  // 创建查询条件
        qw.eq(Bookmark::getDelFlag, 0);  // 查询未删除的收藏
        qw.eq(Bookmark::getUserId, StpUtil.getLoginIdAsLong());  // 查询当前用户的收藏
        qw.orderByDesc(Bookmark::getId);  // 按照ID倒序排序
        Page<Bookmark> page = bookmarkService.page(new Page<>(bookmark.getPageNum(), bookmark.getPageSize()), qw);  // 分页查询收藏
        for (Bookmark item : page.getRecords()) {  // 遍历分页结果
            Cake data = cakeService.getById(item.getDataId());  // 获取收藏的宝藏信息
            Cate cate = cateService.getById(data.getCateId());
            data.setCate(cate);
            item.getExt().set("data", data);  // 将宝藏信息添加到扩展属性中
        }
        return R.ok(new PageVO(page.getTotal(), page.getRecords()));  // 返回分页结果
    }

    // 查询收藏列表
    @PostMapping("/api/bookmark/list")
    public R list(@RequestBody Bookmark bookmark) {
        LambdaQueryWrapper<Bookmark> qw = new LambdaQueryWrapper<>();  // 创建查询条件
        qw.eq(Bookmark::getDelFlag, 0);  // 查询未删除的收藏
        qw.orderByDesc(Bookmark::getId);  // 按照ID倒序排序
        List<Bookmark> list = bookmarkService.list(qw);  // 查询收藏列表
        return R.ok(list);  // 返回查询结果
    }

    // 添加收藏
    @PostMapping("/api/bookmark/add")
    public R add(@RequestBody Bookmark bookmark) {
        bookmark.setCreateBy(StpUtil.getSession().getString("username"));  // 设置创建者为当前登录用户
        bookmark.setCreateTime(new Date());  // 设置创建时间为当前时间
        bookmarkService.save(bookmark);  // 保存收藏信息
        return R.ok();  // 返回成功响应
    }

    // 修改收藏
    @PostMapping("/api/bookmark/update")
    public R update(@RequestBody Bookmark bookmark) {
        bookmarkService.updateById(bookmark);  // 根据ID更新收藏信息
        return R.ok();  // 返回成功响应
    }

    // 删除收藏
    @PostMapping("/api/bookmark/delete")
    public R delete(@RequestBody Bookmark bookmark) {
        LambdaQueryWrapper<Bookmark> qw = new LambdaQueryWrapper<>();
        qw.in(Bookmark::getId, bookmark.getIds());  // 根据ID列表删除收藏
        bookmark.setDelFlag(1);  // 标记为已删除
        bookmarkService.update(bookmark, qw);  // 批量更新收藏信息
        return R.ok();  // 返回成功响应
    }

    // 查询收藏详情
    @PostMapping("/api/bookmark/detail")
    public R detail(@RequestBody Bookmark bookmark) {
        Bookmark entity = bookmarkService.getById(bookmark.getId());  // 根据ID查询收藏详情
        return R.ok(entity);  // 返回查询结果
    }

    // 下拉选项列表
    @PostMapping("/api/bookmark/options")
    public R options() {
        LambdaQueryWrapper<Bookmark> qw = new LambdaQueryWrapper<>();  // 创建查询条件
        qw.eq(Bookmark::getDelFlag, 0);  // 查询未删除的收藏
        List<Bookmark> bookmarkList = bookmarkService.list(qw);  // 查询收藏列表
        List<Options> list = bookmarkList.stream().map(item -> {  // 转换为 Options 列表
            Options options = new Options();
            options.setLabel("下拉");  // 设置选项显示文本
            options.setValue(item.getId());  // 设置选项值
            return options;
        }).toList();  // 转换为列表
        return R.ok(list);  // 返回 Options 列表
    }

    // 查询是否已收藏
    @PostMapping("/api/bookmark/check")
    public R check(@RequestBody Bookmark bookmark) {
        LambdaQueryWrapper<Bookmark> qw = new LambdaQueryWrapper<>();  // 创建查询条件
        qw.eq(Bookmark::getDelFlag, 0);  // 查询未删除的收藏
        qw.eq(Bookmark::getUserId, StpUtil.getLoginIdAsLong());  // 查询当前用户的收藏
        qw.eq(Bookmark::getDataId, bookmark.getDataId());  // 查询指定数据的收藏
        long count = bookmarkService.count(qw);  // 查询符合条件的收藏数量
        return R.ok(count == 1);  // 返回查询结果是否为1
    }

    // 切换收藏状态
    @PostMapping("/api/bookmark/toggle")
    public R toggle(@RequestBody Bookmark bookmark) {
        LambdaQueryWrapper<Bookmark> qw = new LambdaQueryWrapper<>();  // 创建查询条件
        qw.eq(Bookmark::getDelFlag, 0);  // 查询未删除的收藏
        qw.eq(Bookmark::getUserId, StpUtil.getLoginIdAsLong());  // 查询当前用户的收藏
        qw.eq(Bookmark::getDataId, bookmark.getDataId());  // 查询指定数据的收藏
        Bookmark one = bookmarkService.getOne(qw);  // 查询符合条件的唯一收藏
        if (one == null) {  // 如果收藏不存在，则添加收藏
            one = new Bookmark();
            one.setCreateBy(StpUtil.getSession().getString("username"));  // 设置创建者为当前登录用户
            one.setDataId(bookmark.getDataId());  // 设置收藏的数据ID
            one.setUserId(StpUtil.getLoginIdAsLong());  // 设置收藏的用户ID
            one.setCreateTime(new Date());  // 设置创建时间为当前时间
            bookmarkService.save(one);  // 保存收藏
        } else {  // 如果收藏已存在，则删除收藏
            bookmarkService.removeById(one.getId());  // 根据ID删除收藏
        }
        return R.ok();  // 返回成功响应
    }
}

