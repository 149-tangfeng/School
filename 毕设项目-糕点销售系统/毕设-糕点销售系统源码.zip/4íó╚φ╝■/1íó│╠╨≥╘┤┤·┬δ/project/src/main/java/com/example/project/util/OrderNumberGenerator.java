package com.example.project.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class OrderNumberGenerator {

    private static long sequence = 0L;

    public static synchronized String generateOrderNumber() {
        // 获取当前时间，格式为yyyyMMddHHmmss
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = sdf.format(new Date());

        // 生成随机三位数
        Random random = new Random();
        int randomNumber = random.nextInt(900) + 100; // 生成 [100, 999] 范围内的随机数

        // 组合订单号
        return timestamp + String.format("%03d", randomNumber) + String.format("%04d", getNextSequence());
    }

    private static long getNextSequence() {
        sequence = (sequence + 1) % 10000;
        return sequence;
    }

    public static void main(String[] args) {
        String orderNumber = generateOrderNumber();
        System.out.println("生成的订单号：" + orderNumber);
    }
}
