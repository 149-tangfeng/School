package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Feedback;
import com.example.project.mapper.FeedbackMapper;
import org.springframework.stereotype.Service;

/**
 * 留言板
 */
@Service
public class FeedbackService extends ServiceImpl<FeedbackMapper, Feedback> {

}
