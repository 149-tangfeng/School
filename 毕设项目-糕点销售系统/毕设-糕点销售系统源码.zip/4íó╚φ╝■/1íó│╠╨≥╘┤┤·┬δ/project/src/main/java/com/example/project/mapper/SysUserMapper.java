package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.SysUser;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户
 */
@Mapper
public interface SysUserMapper extends BaseMapper<SysUser> {

}