package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Cate;
import com.example.project.entity.Options;
import com.example.project.service.CateService;
import com.example.project.util.ObjectUtil;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 蛋糕分类
 */
@Slf4j
@RestController
public class CateController {

    @Autowired
    private CateService cateService;

    // 分页
    @PostMapping("/api/cate/page")
    public R page(@RequestBody Cate cate) {
        LambdaQueryWrapper<Cate> qw = new LambdaQueryWrapper<>();
        qw.eq(Cate::getDelFlag, 0);
        qw.like(ObjectUtil.isNotEmpty(cate.getName()), Cate::getName, cate.getName());
        qw.orderByDesc(Cate::getId);
        Page<Cate> page = cateService.page(
                new Page<>(cate.getPageNum(), cate.getPageSize()),
                qw
        );
        return R.ok(new PageVO(page.getTotal(), page.getRecords()));
    }

    // 列表
    @PostMapping("/api/cate/list")
    public R list(@RequestBody Cate cate) {
        LambdaQueryWrapper<Cate> qw = new LambdaQueryWrapper<>();
        qw.eq(Cate::getDelFlag, 0);
        qw.orderByDesc(Cate::getId);
        List<Cate> list = cateService.list(qw);
        return R.ok(list);
    }

    // 添加
    @PostMapping("/api/cate/add")
    public R add(@RequestBody Cate cate) {
        cate.setCreateBy(StpUtil.getSession().getString("username"));
        cate.setCreateTime(new Date());
        cateService.save(cate);
        return R.ok();
    }

    // 修改
    @PostMapping("/api/cate/update")
    public R update(@RequestBody Cate cate) {
        cateService.updateById(cate);
        return R.ok();
    }

    // 删除
    @PostMapping("/api/cate/delete")
    public R delete(@RequestBody Cate cate) {
        LambdaQueryWrapper<Cate> qw = new LambdaQueryWrapper<>();
        qw.in(Cate::getId, cate.getIds());
        cate.setDelFlag(1);
        cateService.update(cate, qw);
        return R.ok();
    }

    // 详情
    @PostMapping("/api/cate/detail")
    public R detail(@RequestBody Cate cate) {
        Cate entity = cateService.getById(cate.getId());
        return R.ok(entity);
    }

    //下拉列表
    @PostMapping("/api/cate/options")
    public R options() {
        LambdaQueryWrapper<Cate> qw = new LambdaQueryWrapper<>();
        qw.eq(Cate::getDelFlag, 0);
        List<Cate> cateList = cateService.list(qw);
        List<Options> list = cateList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉");
            options.setValue(item.getId());
            return options;
        }).toList();
        return R.ok(list);
    }
}