package com.example.project.entity;

import cn.hutool.core.lang.Dict;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 订单
 */
@Data
@TableName("orders")
public class Orders implements Serializable {
    //
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    //用户ID
    private Long userId;
    //蛋糕ID
    private Long cakeId;
    //蛋糕名
    private String cakeName;
    //蛋糕分类ID
    private Long cateId;
    //单价
    private BigDecimal price;
    //数量
    private Integer quantity;
    //订单金额
    private BigDecimal cost;
    //订单编号
    private String sn;
    //
    private Integer delFlag;
    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    //创建人
    private String createBy;

    // ==============================
    @TableField(exist = false)
    private Dict ext = Dict.create();
    //页码，从1开始
    @TableField(exist = false)
    private Integer pageNum;
    //每页查询数
    @TableField(exist = false)
    private Integer pageSize;
    @TableField(exist = false)
    private List<Long> ids;
    @TableField(exist = false)
    private Cake cake;
}
