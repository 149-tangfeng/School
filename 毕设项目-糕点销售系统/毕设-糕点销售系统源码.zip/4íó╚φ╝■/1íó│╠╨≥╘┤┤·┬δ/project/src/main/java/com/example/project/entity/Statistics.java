package com.example.project.entity;

import cn.hutool.core.lang.Dict;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 统计数据类，包括用户数量、订单数量、评论数量以及按类别和产品分类的销售数据。
 */
@Data
public class Statistics {

    /**
     * 用户数量
     */
    private Long userCount;
    /**
     * 新增用户数量
     */
    private Long userIncrease;

    /**
     * 订单数量
     */
    private Long orderCount;
    /**
     * 新增订单数量
     */
    private Long orderIncrease;

    /**
     * 评论数量
     */
    private Long commentCount;
    /**
     * 新增评论数量
     */
    private Long commentIncrease;

    /**
     * 按类别分类的销售数据。
     * 列表中的每个条目表示一个包含类别名称和对应销售数量的映射。
     */
    private List<Map<String, Long>> salesDataByCate;

    /**
     * 按产品分类的销售数据。
     * 列表中的每个条目表示一个包含产品名称和对应销售数量的映射。
     */
    private List<Map<String, Long>> salesDataByProduct;


    // ==============================
    @TableField(exist = false)
    private Dict ext = Dict.create();
    //页码，从1开始
    @TableField(exist = false)
    private Integer pageNum;
    //每页查询数
    @TableField(exist = false)
    private Integer pageSize;
    @TableField(exist = false)
    private List<Long> ids;

}
