package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Banner;
import com.example.project.entity.Options;
import com.example.project.service.BannerService;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 轮播图控制器，用于处理轮播图相关的请求
 */
@Slf4j
@RestController
public class BannerController {

    @Autowired
    private BannerService bannerService; // 注入轮播图服务

    // 分页查询轮播图
    @PostMapping("/api/banner/page")
    public R page(@RequestBody Banner banner) {
        // 创建查询条件
        LambdaQueryWrapper<Banner> qw = new LambdaQueryWrapper<>();
        qw.eq(Banner::getDelFlag, 0); // 等于0表示未删除的轮播图
        qw.orderByAsc(Banner::getSortNo); // 按排序号升序排序
        // 调用服务进行分页查询
        Page<Banner> page = bannerService.page(
                new Page<>(banner.getPageNum(), banner.getPageSize()), // 分页参数
                qw
        );
        return R.ok(new PageVO(page.getTotal(), page.getRecords())); // 返回分页结果
    }

    // 查询所有轮播图列表
    @PostMapping("/api/banner/list")
    public R list(@RequestBody Banner banner) {
        LambdaQueryWrapper<Banner> qw = new LambdaQueryWrapper<>();
        qw.eq(Banner::getDelFlag, 0); // 等于0表示未删除的轮播图
        qw.orderByAsc(Banner::getSortNo); // 按排序号升序排序
        // 调用服务查询所有轮播图
        Page<Banner> page = bannerService.page(new Page<>(1, 5), qw); // 默认查询第一页的五条数据
        return R.ok(page.getRecords()); // 返回查询结果
    }

    // 添加轮播图
    @PostMapping("/api/banner/add")
    public R add(@RequestBody Banner banner) {
        // 设置创建人和创建时间
        banner.setCreateBy(StpUtil.getSession().getString("username")); // 获取当前登录用户的用户名
        banner.setCreateTime(new Date()); // 设置当前时间为创建时间
        bannerService.save(banner); // 调用服务保存轮播图
        return R.ok(); // 返回操作成功
    }

    // 修改轮播图
    @PostMapping("/api/banner/update")
    public R update(@RequestBody Banner banner) {
        bannerService.updateById(banner); // 根据ID更新轮播图信息
        return R.ok(); // 返回操作成功
    }

    // 删除轮播图
    @PostMapping("/api/banner/delete")
    public R delete(@RequestBody Banner banner) {
        LambdaQueryWrapper<Banner> qw = new LambdaQueryWrapper<>();
        qw.in(Banner::getId, banner.getIds()); // 根据ID列表删除轮播图
        banner.setDelFlag(1); // 设置删除标志为1表示已删除
        bannerService.update(banner, qw); // 批量更新轮播图信息
        return R.ok(); // 返回操作成功
    }

    // 查询轮播图详情
    @PostMapping("/api/banner/detail")
    public R detail(@RequestBody Banner banner) {
        Banner entity = bannerService.getById(banner.getId()); // 根据ID查询轮播图详情
        return R.ok(entity); // 返回查询结果
    }

    // 获取轮播图下拉选项列表
    @PostMapping("/api/banner/options")
    public R options() {
        LambdaQueryWrapper<Banner> qw = new LambdaQueryWrapper<>();
        qw.eq(Banner::getDelFlag, 0); // 等于0表示未删除的轮播图
        // 查询所有轮播图
        List<Banner> bannerList = bannerService.list(qw);
        // 构建下拉选项列表
        List<Options> list = bannerList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉"); // 设置选项标签
            options.setValue(item.getId()); // 设置选项值为轮播图ID
            return options;
        }).toList();
        return R.ok(list); // 返回下拉选项列表
    }
}
