package com.example.project.config;

import com.example.project.util.R;
import lombok.Getter;

@Getter
public class ResultException extends RuntimeException {

    private final R r;

    public ResultException(R r) {
        super(r.getMsg());
        this.r = r;
    }

}
