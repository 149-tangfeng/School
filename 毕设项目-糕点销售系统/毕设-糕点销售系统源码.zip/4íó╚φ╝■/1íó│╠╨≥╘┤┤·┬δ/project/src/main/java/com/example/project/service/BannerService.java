package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Banner;
import com.example.project.mapper.BannerMapper;
import org.springframework.stereotype.Service;

/**
 * 轮播图
 */
@Service
public class BannerService extends ServiceImpl<BannerMapper, Banner> {

}
