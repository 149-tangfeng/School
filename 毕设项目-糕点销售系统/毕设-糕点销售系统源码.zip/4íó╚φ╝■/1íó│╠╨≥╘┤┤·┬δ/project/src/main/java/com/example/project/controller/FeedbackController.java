package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Feedback;
import com.example.project.entity.Options;
import com.example.project.entity.SysUser;
import com.example.project.service.FeedbackService;
import com.example.project.service.SysUserService;
import com.example.project.util.ObjectUtil;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 留言板管理控制器，处理留言板相关的请求
 */
@Slf4j
@RestController
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService; // 留言板服务
    @Autowired
    private SysUserService sysUserService; // 系统用户服务

    // 分页查询留言板列表
    @PostMapping("/api/feedback/page")
    public R page(@RequestBody Feedback feedback) {
        LambdaQueryWrapper<Feedback> qw = new LambdaQueryWrapper<>();
        qw.eq(Feedback::getDelFlag, 0); // 查询未删除的留言板
        qw.like(ObjectUtil.isNotEmpty(feedback.getContent()), Feedback::getContent, feedback.getContent()); // 模糊匹配留言内容
        // 判断用户权限，管理员可以查看所有留言，普通用户只能查看自己的留言或标记为精选的留言
        if (StpUtil.getSession().getInt("isAdmin") == 0) {
            qw.eq(Feedback::getFeedbackStatus, "精选");
            qw.or(wrapper -> wrapper.eq(Feedback::getUserId, StpUtil.getLoginIdAsLong()));
        }
        qw.orderByDesc(Feedback::getId); // 按照ID倒序排列
        Page<Feedback> page = feedbackService.page(
                new Page<>(feedback.getPageNum(), feedback.getPageSize()), qw);
        for (Feedback item : page.getRecords()) {
            SysUser user = sysUserService.getById(item.getUserId());
            item.getExt().set("user", user); // 设置留言关联的用户信息
        }
        return R.ok(new PageVO(page.getTotal(), page.getRecords())); // 返回分页结果
    }

    // 查询留言板列表
    @PostMapping("/api/feedback/list")
    public R list(@RequestBody Feedback feedback) {
        LambdaQueryWrapper<Feedback> qw = new LambdaQueryWrapper<>();
        qw.eq(Feedback::getDelFlag, 0); // 查询未删除的留言板
        qw.orderByDesc(Feedback::getId); // 按照ID倒序排列
        List<Feedback> list = feedbackService.list(qw);
        return R.ok(list); // 返回查询结果列表
    }

    // 添加留言板
    @PostMapping("/api/feedback/add")
    public R add(@RequestBody Feedback feedback) {
        feedback.setUserId(StpUtil.getLoginIdAsLong()); // 设置留言用户ID为当前登录用户
        feedback.setCreateBy(StpUtil.getSession().getString("username")); // 设置创建者
        feedback.setCreateTime(new Date()); // 设置创建时间为当前时间
        feedbackService.save(feedback); // 保存留言板信息
        return R.ok(); // 返回成功响应
    }

    // 修改留言板信息
    @PostMapping("/api/feedback/update")
    public R update(@RequestBody Feedback feedback) {
        feedbackService.updateById(feedback); // 根据ID更新留言板信息
        return R.ok(); // 返回成功响应
    }

    // 删除留言板
    @PostMapping("/api/feedback/delete")
    public R delete(@RequestBody Feedback feedback) {
        LambdaQueryWrapper<Feedback> qw = new LambdaQueryWrapper<>();
        qw.in(Feedback::getId, feedback.getIds()); // 根据ID列表删除留言板
        feedback.setDelFlag(1); // 标记为已删除
        feedbackService.update(feedback, qw); // 批量更新留言板信息
        return R.ok(); // 返回成功响应
    }

    // 查询留言板详情
    @PostMapping("/api/feedback/detail")
    public R detail(@RequestBody Feedback feedback) {
        Feedback entity = feedbackService.getById(feedback.getId()); // 根据ID查询留言板详情
        return R.ok(entity); // 返回留言板详情
    }

    // 查询留言板下拉列表
    @PostMapping("/api/feedback/options")
    public R options() {
        LambdaQueryWrapper<Feedback> qw = new LambdaQueryWrapper<>();
        qw.eq(Feedback::getDelFlag, 0); // 查询未删除的留言板
        List<Feedback> feedbackList = feedbackService.list(qw);
        // 构建下拉列表选项
        List<Options> list = feedbackList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉"); // 设置选项显示文本
            options.setValue(item.getId()); // 设置选项值
            return options;
        }).toList();
        return R.ok(list); // 返回留言板下拉列表
    }
}
