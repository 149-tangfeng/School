package com.example.project.entity;

import cn.hutool.core.lang.Dict;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 商品评论
 */
@Data
@TableName("comments")
public class Comments implements Serializable {
    //
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    //评论对象ID
    private Long dataId;
    //评论内容
    private String content;
    //
    private Integer delFlag;
    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    //创建人
    private String createBy;
    //上级评论ID
    private Long pId;
    //评论人用户ID
    private Long userId;

    // ==============================
    @TableField(exist = false)
    private Dict ext = Dict.create();
    //页码，从1开始
    @TableField(exist = false)
    private Integer pageNum;
    //每页查询数
    @TableField(exist = false)
    private Integer pageSize;
    @TableField(exist = false)
    private List<Long> ids;

    @TableField(exist = false)
    private SysUser user;
}
