package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Cake;
import org.apache.ibatis.annotations.Mapper;

/**
 * 蛋糕
 */
@Mapper
public interface CakeMapper extends BaseMapper<Cake> {

}