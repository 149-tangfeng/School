package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Feedback;
import org.apache.ibatis.annotations.Mapper;

/**
 * 留言板
 */
@Mapper
public interface FeedbackMapper extends BaseMapper<Feedback> {

}