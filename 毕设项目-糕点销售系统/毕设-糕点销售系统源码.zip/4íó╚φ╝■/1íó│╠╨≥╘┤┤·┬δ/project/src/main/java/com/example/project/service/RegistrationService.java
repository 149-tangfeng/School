package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Registration;
import com.example.project.mapper.RegistrationMapper;
import org.springframework.stereotype.Service;

/**
 * 活动报名
 */
@Service
public class RegistrationService extends ServiceImpl<RegistrationMapper, Registration> {

}
