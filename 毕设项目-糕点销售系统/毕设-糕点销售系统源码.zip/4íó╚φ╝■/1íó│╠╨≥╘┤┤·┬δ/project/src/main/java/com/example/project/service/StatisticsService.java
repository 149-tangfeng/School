package com.example.project.service;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Statistics;
import com.example.project.mapper.StatisticsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 轮播图
 */
@Service
public class StatisticsService extends ServiceImpl<StatisticsMapper, Statistics> {

    @Autowired
    private StatisticsMapper statisticsMapper;

    public Statistics selectCountInfo(DateTime beginOfDay) {
        return statisticsMapper.selectCountInfo(beginOfDay);
    }
}
