package com.example.project.entity;

import cn.hutool.core.lang.Dict;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 用户
 */
@Data
@TableName("sys_user")
public class SysUser implements Serializable {
    //主键
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    //类型
    private String userType;
    //用户名
    private String username;
    //密码
    private String pwd;
    //姓名
    private String displayName;
    //性别
    private String sex;
    //年龄
    private Integer age;
    //手机号
    private String phone;
    //头像
    private String img;
    //是否删除
    private Integer delFlag;
    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    //创建人
    private String createBy;

    // ==============================
    @TableField(exist = false)
    private Dict ext = Dict.create();
    //页码，从1开始
    @TableField(exist = false)
    private Integer pageNum;
    //每页查询数
    @TableField(exist = false)
    private Integer pageSize;
    @TableField(exist = false)
    private String token;
    @TableField(exist = false)
    private String oldpwd;
    @TableField(exist = false)
    private String newpwd;
    @TableField(exist = false)
    private List<Long> ids;

}
