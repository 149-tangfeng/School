package com.example.project.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.project.entity.Notice;
import com.example.project.entity.Options;
import com.example.project.service.NoticeService;
import com.example.project.util.ObjectUtil;
import com.example.project.util.PageVO;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 公告控制器，用于处理公告相关的请求
 */
@Slf4j
@RestController
public class NoticeController {

    @Autowired
    private NoticeService noticeService; // 注入公告服务

    // 分页查询公告
    @PostMapping("/api/notice/page")
    public R page(@RequestBody Notice notice) {
        // 创建查询条件
        LambdaQueryWrapper<Notice> qw = new LambdaQueryWrapper<>();
        qw.eq(Notice::getDelFlag, 0); // 等于0表示未删除的公告
        qw.like(ObjectUtil.isNotEmpty(notice.getTitle()), Notice::getTitle, notice.getTitle()); // 根据标题模糊查询
        qw.orderByDesc(Notice::getId); // 按ID倒序排序
        // 调用服务进行分页查询
        Page<Notice> page = noticeService.page(
                new Page<>(notice.getPageNum(), notice.getPageSize()), // 分页参数
                qw
        );
        return R.ok(new PageVO(page.getTotal(), page.getRecords())); // 返回分页结果
    }

    // 查询所有公告列表
    @PostMapping("/api/notice/list")
    public R list(@RequestBody Notice notice) {
        LambdaQueryWrapper<Notice> qw = new LambdaQueryWrapper<>();
        qw.eq(Notice::getDelFlag, 0); // 等于0表示未删除的公告
        qw.orderByDesc(Notice::getId); // 按ID倒序排序
        // 调用服务查询所有公告
        List<Notice> list = noticeService.list(qw);
        return R.ok(list); // 返回查询结果
    }

    // 添加公告
    @PostMapping("/api/notice/add")
    public R add(@RequestBody Notice notice) {
        // 设置创建人和创建时间
        notice.setCreateBy(StpUtil.getSession().getString("username")); // 获取当前登录用户的用户名
        notice.setCreateTime(new Date()); // 设置当前时间为创建时间
        noticeService.save(notice); // 调用服务保存公告
        return R.ok(); // 返回操作成功
    }

    // 修改公告
    @PostMapping("/api/notice/update")
    public R update(@RequestBody Notice notice) {
        noticeService.updateById(notice); // 根据ID更新公告信息
        return R.ok(); // 返回操作成功
    }

    // 删除公告
    @PostMapping("/api/notice/delete")
    public R delete(@RequestBody Notice notice) {
        LambdaQueryWrapper<Notice> qw = new LambdaQueryWrapper<>();
        qw.in(Notice::getId, notice.getIds()); // 根据ID列表删除公告
        notice.setDelFlag(1); // 设置删除标志为1表示已删除
        noticeService.update(notice, qw); // 批量更新公告信息
        return R.ok(); // 返回操作成功
    }

    // 查询公告详情
    @PostMapping("/api/notice/detail")
    public R detail(@RequestBody Notice notice) {
        Notice entity = noticeService.getById(notice.getId()); // 根据ID查询公告详情
        return R.ok(entity); // 返回查询结果
    }

    // 获取公告下拉选项列表
    @PostMapping("/api/notice/options")
    public R options() {
        LambdaQueryWrapper<Notice> qw = new LambdaQueryWrapper<>();
        qw.eq(Notice::getDelFlag, 0); // 等于0表示未删除的公告
        // 查询所有公告
        List<Notice> noticeList = noticeService.list(qw);
        // 构建下拉选项列表
        List<Options> list = noticeList.stream().map(item -> {
            Options options = new Options();
            options.setLabel("下拉"); // 设置选项标签
            options.setValue(item.getId()); // 设置选项值为公告ID
            return options;
        }).toList();
        return R.ok(list); // 返回下拉选项列表
    }
}
