package com.example.project.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.project.entity.Cake;
import com.example.project.entity.Cate;
import com.example.project.entity.Orders;
import com.example.project.entity.Statistics;
import com.example.project.service.CakeService;
import com.example.project.service.CateService;
import com.example.project.service.OrdersService;
import com.example.project.service.StatisticsService;
import com.example.project.util.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 数据统计控制器
 */
@Slf4j
@RestController
public class StatisticsController {


    @Autowired
    private CakeService cakeService;
    @Autowired
    private CateService cateService;
    @Autowired
    private OrdersService ordersService;
    @Autowired
    private StatisticsService statisticsService;


    // 销量统计
    @PostMapping("/api/statistics/analysis")
    public R sales(@RequestBody Statistics statistics) {
        DateTime beginOfDay = DateUtil.beginOfDay(new Date());
        Statistics sta = statisticsService.selectCountInfo(beginOfDay);

        List<Cate> cateList = cateService.list();
        List<Cake> cakeList = cakeService.list();

        LambdaQueryWrapper<Orders> ordersQueryWrapper = new LambdaQueryWrapper<>();
        List<Orders> orderList = ordersService.list();
        Map<Long, Long> salesMapByCate = orderList.stream().collect(Collectors.groupingBy(Orders::getCateId, Collectors.summingLong(Orders::getQuantity)));
        Map<Long, Long> salesMapByProduct = orderList.stream().collect(Collectors.groupingBy(Orders::getCakeId, Collectors.summingLong(Orders::getQuantity)));

        List<Map<String, Long>> salesDataByCate = new ArrayList<>();
        List<Map<String, Long>> salesDataByProduct = new ArrayList<>();
        cateList.stream().forEach(cate -> {
            Long cateId = cate.getId();
            Long salesCount = salesMapByCate.get(cateId);
            if (salesCount == null) {
                salesCount = 0L;
            }
            Map<String, Long> map = new HashMap<>();
            map.put(cate.getName(), salesCount);
            salesDataByCate.add(map);
        });
        cakeList.stream().forEach(cake -> {
            Long cakeId = cake.getId();
            Long salesCount = salesMapByProduct.get(cakeId);
            if (salesCount == null) {
                salesCount = 0L;
            }
            Map<String, Long> map = new HashMap<>();
            map.put(cake.getName(), salesCount);
            salesDataByProduct.add(map);
        });

        sta.setSalesDataByCate(salesDataByCate);
        sta.setSalesDataByProduct(salesDataByProduct);

        return R.ok(sta);
    }
}
