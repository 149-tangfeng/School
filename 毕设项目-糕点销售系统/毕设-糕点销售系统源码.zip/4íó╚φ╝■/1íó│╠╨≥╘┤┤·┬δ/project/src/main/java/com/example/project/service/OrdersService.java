package com.example.project.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.project.entity.Orders;
import com.example.project.mapper.OrdersMapper;
import org.springframework.stereotype.Service;

/**
 * 订单
 */
@Service
public class OrdersService extends ServiceImpl<OrdersMapper, Orders> {

}
