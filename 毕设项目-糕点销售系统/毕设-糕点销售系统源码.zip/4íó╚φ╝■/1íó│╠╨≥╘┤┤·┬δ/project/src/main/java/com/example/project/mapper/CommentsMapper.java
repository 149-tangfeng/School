package com.example.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.project.entity.Comments;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品评论
 */
@Mapper
public interface CommentsMapper extends BaseMapper<Comments> {

}