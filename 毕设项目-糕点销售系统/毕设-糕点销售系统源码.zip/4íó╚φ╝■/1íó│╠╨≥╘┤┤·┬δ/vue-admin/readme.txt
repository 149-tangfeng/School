安装yarn 
npm install -g yarn

安装依赖
yarn 
或者
npm install 

备选
慎用
npm install --registry=http://registry.npm.taobao.org