import { createApp } from "vue";
import { createPinia } from "pinia";
import router from "@/utils/router";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import * as ElementPlusIconsVue from "@element-plus/icons-vue";
import App from "./App.vue";
import "./style.css";
import piniaPersist from "pinia-plugin-persist";
// 分页组件
import Pagination from "@/components/Pagination/index.vue";
// 富文本组件
import Editor from "@/components/Editor/index.vue";
// 文件上传组件
import FileUpload from "@/components/FileUpload/index.vue";
// 图片上传组件
import ImageUpload from "@/components/ImageUpload/index.vue";
// 图片预览组件
import ImagePreview from "@/components/ImagePreview/index.vue";
import plugins from "@/utils/index.js";

const app = createApp(App);
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component);
}
const pinia = createPinia();
pinia.use(piniaPersist);

// 全局组件挂载
app.component("Pagination", Pagination);
app.component("FileUpload", FileUpload);
app.component("ImageUpload", ImageUpload);
app.component("ImagePreview", ImagePreview);
app.component("Editor", Editor);

app.use(plugins);
app.use(ElementPlus);
app.use(router);
app.use(pinia);
app.mount("#app");
