import modal from "./modal";

export default function installPlugins(app) {
    app.config.globalProperties.$modal = modal;
}
