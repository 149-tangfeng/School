import { defineStore } from "pinia";
import { reactive, ref } from "vue";
import router from "@/utils/router.js";

// 定义名为 "main" 的 Pinia store
export const useMainStore = defineStore(
    "main",
    () => {
        // 使用 ref() 和 reactive() 创建响应式数据
        const curuser = ref({}); // 当前用户信息
        const tmpData = ref({}); // 临时数据，传值用
        const userType = ref("");
        const userId = ref(null);

        // 返回需要暴露给外部的数据和方法
        return {
            curuser,
            tmpData,
            userType,
            userId,
        };
    },
    {
        persist: {
            enabled: true, // 启用持久化
        },
    },
);
