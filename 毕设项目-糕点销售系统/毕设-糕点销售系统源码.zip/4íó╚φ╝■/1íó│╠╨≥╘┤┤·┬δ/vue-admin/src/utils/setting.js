// 管理员 菜单列表
const adminMenu = [
    { name: "数据统计", path: "/statistics" },
    { name: "用户管理", path: "/user" },
    { name: "订单管理", path: "/orders" },
    { name: "分类管理", path: "/cate" },
    { name: "糕点管理", path: "/cake" },    
    { name: "轮播图管理", path: "/banner" },    
    { name: "公告管理", path: "/notice" },
    { name: "评价管理", path: "/comments" },    
    { name: "留言板管理", path: "/feedback" },
//    { name: "敏感词管理", path: "/sensitiveWord" }
];
// 用户 权威用户 菜单列表
const userMenu = [
    { name: "首页", path: "/cake" },
    { name: "我的订单", path: "/orders" },
    { name: "我的收藏", path: "/bookmark" },
    { name: "留言板", path: "/feedback" },
];

// 获取菜单列表
function getMenu() {
    const userType = sessionStorage.getItem("userType");
    if (userType == "管理员") {
        // 如果当前用户是管理员
        return adminMenu;
    }
    return userMenu;
}

// 获取首页
function getFirstMenu() {
    return getMenu()[0].path;
}

const title = "留香斋糕点销售管理系统";
const uploadURL = "http://localhost:8080/upload";
const baseURL = "http://localhost:8080";

//下载
async function downloadFile(name, href) {
    try {
        // 发起后端请求获取文件的二进制数据
        const response = await fetch(href, {
            method: "GET",
            headers: {
                "Content-Type": "application/octet-stream", // 设置请求头为二进制流类型
            },
        });
        if (!response.ok) {
            console.error("下载失败");
            return false;
        }
        // 将二进制数据转换为 Blob 对象
        const blob = await response.blob();
        // 创建一个虚拟链接
        const link = document.createElement("a");
        // 设置链接的 href 属性为 Blob 对象的 URL
        link.href = URL.createObjectURL(blob);
        // 设置下载属性为文件名（如果服务端提供文件名的话）
        link.download = name; // 替换为您的文件名
        // 模拟点击链接进行下载
        link.click();

        // 释放 Blob 对象的 URL
        URL.revokeObjectURL(link.href);
    } catch (error) {
        console.error("下载文件失败:", error);
    }
}

// 清空已有数据
const clearFormData = function (obj) {
    for (const key in obj) {
        obj[key] = null; // 或者你可以设置为其他默认值
    }
};

// 复制
const copyData = function (obj) {
    return JSON.parse(JSON.stringify(obj));
};

const setting = {
    getMenu,
    getFirstMenu,
    title,
    uploadURL,
    baseURL,
    downloadFile,
    clearFormData,
    copyData,
};

export default setting;
