const dict = {
    sex: [
        {
            value: "男",
            label: "男",
        },
        {
            value: "女",
            label: "女",
        },
    ],
    userType: [
        {
            value: "管理员",
            label: "管理员",
        },
        {
            value: "用户",
            label: "用户",
        },
    ],
    activityStatus: [
        {
            value: "申请中",
            label: "申请中",
        },
        {
            value: "进行中",
            label: "进行中",
        },
        {
            value: "已拒绝",
            label: "已拒绝",
        },
        {
            value: "已结束",
            label: "已结束",
        },
    ],
    applicationStatus: [
        {
            value: "申请中",
            label: "申请中",
        },
        {
            value: "已通过",
            label: "已通过",
        },
        {
            value: "已拒绝",
            label: "已拒绝",
        },
    ],
};
export default dict;
