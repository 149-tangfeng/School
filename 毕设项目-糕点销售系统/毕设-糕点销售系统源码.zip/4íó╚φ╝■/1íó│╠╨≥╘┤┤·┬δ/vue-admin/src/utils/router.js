import { createRouter, createWebHistory } from "vue-router";
import setting from "@/utils/setting.js";

//路由
const routes = [

    {
        path: "/comments",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/comments.vue"),
            },
        ],
    },
    {
        path: "/cake",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/cake.vue"),
            },
        ],
    },
    {
        path: "/cakeDetail",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/cakeDetail.vue"),
            },
        ],
    },
    {
        path: "/cate",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/cate.vue"),
            },
        ],
    },
    {
        path: "/orders",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/orders.vue"),
            },
        ],
    },
    {
        path: "/noticeDetail",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/noticeDetail.vue"),
            },
        ],
    },
    {
        path: "/notice",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/notice.vue"),
            },
        ],
    },
    {
        path: "/banner",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/banner.vue"),
            },
        ],
    },
    {
        path: "/my",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/my.vue"),
            },
        ],
    },
    {
        path: "/user",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/user.vue"),
            },
        ],
    },
    {
        path: "/feedback",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/feedback.vue"),
            },
        ],
    },
    {
        path: "/bookmark",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/bookmark.vue"),
            },
        ],
    },
    {
        path: "/statistics",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/statistics.vue"),
            },
        ],
    },
    {
        path: "/registration",
        component: () => import("@/views/index.vue"),
        children: [
            {
                path: "",
                component: () => import("@/views/registration.vue"),
            },
        ],
    },
	
 //   {
 //      path: "/sensitiveWord",
 //       component: () => import("@/views/index.vue"),
 //      children: [
 //           {
 //               path: "",
 //               component: () => import("@/views/sensitiveWord.vue"),
 //           },
 //       ],
 //   },

    {
        path: "/login",
        component: () => import("@/views/login.vue"),
    },
    {
        path: "/reg",
        component: () => import("@/views/reg.vue"),
    },
    {
        path: "/",
        component: () => import("@/views/home.vue"),
    },

    {
        path: "/home",
        component: () => import("@/views/home.vue"),
    },

];

/**
 * 创建并配置路由器实例。
 * 使用现代浏览器的history模式来管理应用的路由，提供了更自然的URL。
 * 可以选择使用hash模式来兼容不支持history模式的旧浏览器或服务器配置。
 */
const router = createRouter({
    history: createWebHistory(), // 使用history模式
    //   history: createWebHashHistory(), // 使用hash模式
    routes,
});

//白名单
const list = ["/login", "/reg", "/home"];

//前置守卫
router.beforeEach((to, from) => {
    const token = sessionStorage.getItem("token");
    // 返回 false 以取消导航
    if (list.includes(to.path)) {
        return true;
    } else if (!token) {
        return "/home";
    }
    if (to.path == "/") {
        return { path: setting.getFirstMenu(), replace: true };
    }
    return true;
});

export default router;
