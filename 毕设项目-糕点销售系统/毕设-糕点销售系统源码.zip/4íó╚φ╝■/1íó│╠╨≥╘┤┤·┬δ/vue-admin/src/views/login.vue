<template>
    <div class="background">
        <div class="container">
            <div class="centered-div">
                <el-card>
                    <template #header>
                        <div style="text-align: center">
                            <span style="font-weight: bold; font-size: 20px">
                                {{ setting.title }}
                            </span>
                        </div>
                    </template>
                    <el-form ref="formDataRef" :model="formData" label-width="80px" :rules="rules">
                        <el-form-item label="用户名" prop="username" style="margin-top: 20px">
                            <el-input v-model="formData.username" placeholder="请输入用户名" style="width: 250px" />
                        </el-form-item>
                        <el-form-item label="密码" prop="pwd" style="margin-top: 40px">
                            <el-input
                                v-model="formData.pwd"
                                type="password"
                                placeholder="请输入密码"
                                :show-password="true"
                                style="width: 250px"
                                @keyup.enter="handleLogin"
                            />
                        </el-form-item>

                        <div
                            style="
                                text-align: center;
                                display: flex;
                                margin-right: 30px;
                                margin-left: 30px;
                                margin-top: 40px;
                            "
                        >
                            <!-- 登录按钮 -->
                            <el-button type="primary" size="large" @click.prevent="handleLogin" style="flex-grow: 1">
                                登录
                            </el-button>
                            <!-- 注册按钮 -->
                            <el-button size="large" @click.prevent="router.push('/reg')" style="flex-grow: 1">
                                注册
                            </el-button>
                        </div>
                    </el-form>
                </el-card>
            </div>
        </div>
    </div>
</template>
<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                 .............................................
//                          佛祖保佑             永无BUG
import { ElForm, ElMessage } from "element-plus";
import { reactive, ref } from "vue";
import { useMainStore } from "@/utils/store.js"; // 导入 main store
import { useThrottleFn } from "@vueuse/core";
import request from "@/utils/request.js"; // 导入请求模块
import router from "@/utils/router.js";
import setting from "@/utils/setting.js"; // 导入路由模块

const mainStore = useMainStore(); // 获取 main store 实例
const formDataRef = ref(ElForm); // 表单数据引用
const formData = reactive({
    // 响应式表单数据，初始化为默认用户名和密码
    username: "",
    pwd: "",
});
const rules = reactive({
    // 表单校验规则
    username: [{ required: true, message: "请输入用户名", trigger: "blur" }],
    pwd: [{ required: true, message: "请输入密码", trigger: "blur" }],
    typee: [{ required: true, message: "请选择角色", trigger: "blur" }],
});

// 处理登录请求，使用节流函数限制请求频率
const handleLogin = useThrottleFn(() => {
    formDataRef.value.validate((valid) => {
        // 校验表单
        if (valid) {
            request({
                // 发送登录请求
                url: "/login", // 请求地址
                data: formData, // 请求数据
            }).then(({ data }) => {
                // 登录成功后处理返回的用户数据
                mainStore.curuser = data; // 更新当前用户信息到 main store
                mainStore.userType = data.userType;
                mainStore.userId = data.id;
                sessionStorage.setItem("token", data.token); // 将 token 存储到 sessionStorage
                sessionStorage.setItem("userType", data.userType); // 将用户类型存储到 sessionStorage
                router.push("/"); // 跳转到首页
            });
        }
    });
}, 500);
</script>
<style scoped>
.background {
    background-image: url("/bg4.png"); /* 设置背景图片路径 */
    background-size: cover; /* 让背景图片覆盖整个屏幕 */
    background-position: center; /* 将背景图片居中 */
    height: 100vh; /* 使容器占据整个视口的高度 */
}

.container {
    display: flex;
    justify-content: center; /* 在主轴上居中 */
    align-items: center; /* 在交叉轴上居中 */
    height: 100vh; /* 使容器占据整个视口的高度 */
}

.centered-div {
    width: 400px;
    height: 350px;
}
</style>
