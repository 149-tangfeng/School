<script setup></script>

<template>
    <el-form-item label="入职时间" prop="intime">
        <el-date-picker
            v-model="mainStore.curuser.birthdate"
            type="date"
            placeholder="请选择日期"
            style="width: 100%"
            value-format="YYYY-MM-DD"
        />
    </el-form-item>

    <el-table-column label="内容" align="center" prop="content" show-overflow-tooltip />

    <el-table-column label="图片" align="center" prop="img">
        <template #default="scope">
            <el-image
                :preview-teleported="true"
                style="width: 50px; height: 50px"
                :src="scope.row.img"
                :preview-src-list="[scope.row.img]"
                fit="cover"
            />
        </template>
    </el-table-column>

    <el-form-item label="图片" prop="img">
        <el-upload
            style="
                width: 178px;
                height: 178px;
                display: block;
                border: 1px dashed var(--el-border-color);
                border-radius: 6px;
                cursor: pointer;
                position: relative;
                overflow: hidden;
                transition: var(--el-transition-duration-fast);
            "
            :action="mainStore.setting.uploadURL"
            :show-file-list="false"
            :on-success="handleAddAvatarSuccess"
        >
            <img
                v-if="addFormData.img"
                :src="addFormData.img"
                style="width: 178px; height: 178px; display: block; object-fit: cover"
            />
            <el-icon v-else style="font-size: 28px; color: #8c939d; width: 178px; height: 178px; text-align: center">
                <Plus />
            </el-icon>
        </el-upload>
    </el-form-item>

    <el-form-item label="性别" prop="sex">
        <el-select v-model="formData.sex" placeholder="请选择" style="width: 200px">
            <el-option v-for="item in setting.dict.sex" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
    </el-form-item>

    <el-form-item label="内容" prop="namee">
        <el-input
            v-model="mainStore.curuser.shopcontent"
            placeholder="请输入内容"
            type="textarea"
            :autosize="{ minRows: 3 }"
        />
    </el-form-item>

    <el-form-item label="密码" prop="pwd">
        <el-input v-model="addFormData.pwd" placeholder="请输入密码" type="password" show-password />
    </el-form-item>

    <el-upload
        v-model:file-list="fileList"
        :action="mainStore.setting.uploadURL"
        multiple
        :limit="5"
        list-type="picture"
        style="width: 100%"
        :on-success="handleUploadSuccess"
    >
        <el-button type="primary">上传附件</el-button>
        <template #tip>
            <div style="font-size: small; color: gray">最多上传5个</div>
        </template>
    </el-upload>
</template>

<style scoped></style>
