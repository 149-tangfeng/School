<template>

    <div style="margin-top:60px;">
        <div class="navbar">
            <span>
                {{ mainStore.tmpData.cate.name }}>{{ mainStore.tmpData.name }}
            </span>
        </div>

        <div class="common-layout" style="border: 1px solid #eee; padding: 20px;">
            <el-container>
                <el-aside width="200px">
                    <div>
                        <el-image :src="mainStore.tmpData.img" :fit="fit" />
                    </div>
                </el-aside>
                <el-container>
                    <el-header>
                        <div style="text-align: left; font-size: large; font-weight: bold;">
                            {{ mainStore.tmpData.name }}
                        </div>
                    </el-header>
                    <el-main>
                        <div style="font-size: small; color: #e73f32; font-weight: bold;">
                            单价：{{ mainStore.tmpData.price.toFixed(2) }}元/千克
                        </div>
                    </el-main>
                    <el-footer>
                        <div style="text-align: left;">
                            <el-button type="danger" @click="openDialog(mainStore.tmpData)">
                                去购买
                            </el-button>
                            <el-button type="warning" plain @click="handleToggle" style="margin-left: 20px;">
                                {{ bookmarkStatus ? "取消收藏" : "收藏" }}
                            </el-button>
                        </div>
                    </el-footer>
                </el-container>
            </el-container>
        </div>

        <div class="navbar">
            <span>
                详情
            </span>
        </div>
        <div style="padding:20px">
            <span>
                {{ mainStore.tmpData.content }}
            </span>
        </div>

        <div class="navbar">
            <span>
                评价
            </span>
        </div>

        <div style="margin: 20px">
            <div v-if="comments.length === 0">暂无评论</div>
            <div v-else>
                <div v-for="comment in comments" :key="comment.id" class="comment">
                    <el-container>
                        <el-aside width="200px" style="text-align: center;">
                            <img :src="comment.user.img" alt="用户头像" class="avatar">
                            <div class="username">{{ comment.user.displayName.replace(/^(.).*/, '$1***') }}</div>
                        </el-aside>
                        <el-container>
                            <el-main>
                                <div class="content" style="font-size: 14px;">{{ comment.content }}</div>
                            </el-main>
                            <el-footer style="text-align: right;">
                                <div class="time" style="font-size: 12px;">{{ comment.createTime }}</div>
                            </el-footer>
                        </el-container>
                    </el-container>
                </div>
            </div>
        </div>

        <div style="display: flex; justify-content: flex-end; background-color: white">
            <pagination v-show="total > 0" :total="total" v-model:page="queryParams.pageNum"
                v-model:limit="queryParams.pageSize" @pagination="handleQuery" />
        </div>

        <el-dialog v-model="dialog" width="600px" append-to-body @close="closeDialog" v-loading="loading">
            <template #header>
                <span
                    style="font-size: 18px; font-weight: bold; text-align: center; align-items: center; justify-content: center;">下单</span>
            </template>

            <el-form ref="formRef" :model="formData" label-width="80px" :rules="rules">

                <el-form-item label="单价">
                    {{ mainStore.tmpData.price.toFixed(2) }}元/千克
                </el-form-item>

                <el-form-item label="购买数量" prop="quantity">
                    <el-input v-model="formData.quantity" type="number" placeholder="请输入购买数量" />
                </el-form-item>

                <el-form-item label="总价" prop="cost">
                    {{ (formData.quantity * mainStore.tmpData.price).toFixed(2) }}元
                </el-form-item>


            </el-form>
            <template #footer>
                <div>
                    <el-button @click="closeDialog">
                        取消
                    </el-button>
                    <el-button type="primary" @click="handlePurchase">
                        付款
                    </el-button>
                </div>
            </template>
        </el-dialog>

    </div>

</template>

<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                   .............................................
//                            佛祖保佑             永无BUG

import request from "@/utils/request";
import setting from "@/utils/setting.js";
import { useMainStore } from "@/utils/store.js";
import { useThrottleFn } from "@vueuse/core";
import { ElForm, ElMessage } from "element-plus";
import { onMounted, reactive, ref } from "vue";

const mainStore = useMainStore();

// 表单的引用
const formRef = ref(ElForm);
// 表单的数据
const formData = reactive({});
// 加载状态控制
const loading = ref(false);
// 对话框的可见性控制
const dialog = ref(false);
// 收藏状态控制
const bookmarkStatus = ref(false);

// 查询参数
const queryParams = reactive({
    pageNum: 1,
    pageSize: 10,
});

const comments = ref([]);
// 评论总数
const total = ref(0);

const validateQuantity = (rule, value, callback) => {
    if (isNaN(value) || value < 0) {
        callback(new Error('数量必须是一个有效的数字'));
    } else if (value === null || value === '') {
        callback(new Error('数量不能为空'));
    } else {
        callback(); // 验证通过
    }
};
// 表单规则
const rules = reactive({
    quantity: [{ required: true, validator: validateQuantity, trigger: "blur" }],
    cost: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});


//检查收藏状态
function check() {
    request({
        url: "/api/bookmark/check",
        data: {
            dataId: mainStore.tmpData.id,
        },
    }).then(({ data }) => {
        bookmarkStatus.value = data;
    });
}
//收藏/取消收藏
const handleToggle = useThrottleFn(() => {
    request({
        url: "/api/bookmark/toggle",
        data: {
            dataId: mainStore.tmpData.id,
        },
    }).then(() => {
        ElMessage({
            showClose: true,
            message: "操作成功",
            type: "success",
        });
        check();
    });
});

//检查收藏状态
function getComments() {
    queryParams.dataId = mainStore.tmpData.id;
    request({
        url: "/api/comments/page",
        data: queryParams,
    }).then(({ data }) => {
        comments.value = data.list;
        total.value = data.list.length;
    });
}

//购买
const handlePurchase = useThrottleFn(() => {
    formData.userId = mainStore.userId;
    formData.cakeId = mainStore.tmpData.id;
    formData.cateId = mainStore.tmpData.cate.id;
    formData.cakeName = mainStore.tmpData.name;
    formData.price = mainStore.tmpData.price;
    formData.cost = formData.quantity * formData.price;
    loading.value = true;
    formRef.value.validate().then(() => {
        request({
            url: "/api/orders/add",
            data: formData,
        }).then(() => {
            ElMessage({
                showClose: true,
                message: "购买成功",
                type: "success",
            });
            check();
            closeDialog();
            loading.value = false;
        });

    }).catch(() => {
        loading.value = false;
    });

});

//打开对话框
function openDialog(row) {
    dialog.value = true;


}

//关闭对话框，并重置表单
function closeDialog() {
    dialog.value = false;
    formRef.value.resetFields();
    formRef.value.clearValidate();
    setting.clearFormData(formData);

}
//组件挂载时执行初始化查询
onMounted(() => {
    check();
    getComments();
});


</script>

<style scoped>
.navbar {
    height: 30px;
    background-color: #6a8eba;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: left;
    align-items: center;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    padding-left: 10px;

}

.comment {
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
}

.avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
}

.username {
    margin-top: 10px;
    font-weight: bold;
}

.content {
    margin-top: 10px;
}

.time {
    margin-top: 5px;
    color: #999;
}

/* #304156 */
/* #6a8eba */
</style>
