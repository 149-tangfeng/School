<template>
    <el-row>
        <el-col :span="mainStore.userType == '管理员' ? 8 : 12">
            <el-card style="margin: 10px" shadow="never">
                <template #header>
                    <div class="card-header">
                        <span>个人信息</span>
                    </div>
                </template>
                <el-form ref="formRef" :model="mainStore.curuser" label-width="80px" :rules="rules">
                    <el-form-item label="用户名" prop="username">
                        <el-input v-model="mainStore.curuser.username" placeholder="用户名" disabled />
                    </el-form-item>
                    <el-form-item label="姓名" prop="displayName">
                        <el-input v-model="mainStore.curuser.displayName" placeholder="姓名" />
                    </el-form-item>
                    <el-form-item label="性别" prop="sex">
                        <el-select v-model="mainStore.curuser.sex" placeholder="请选择">
                            <el-option
                                v-for="item in dict.sex"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                            />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="年龄" prop="age">
                        <el-input v-model="mainStore.curuser.age" placeholder="年龄" type="number" />
                    </el-form-item>
                    <el-form-item label="手机号" prop="phone">
                        <el-input v-model="mainStore.curuser.phone" placeholder="手机号" />
                    </el-form-item>
                    <el-form-item label="头像" prop="img">
                        <image-upload v-model="mainStore.curuser.img" :limit="1"></image-upload>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <div style="text-align: center">
                        <el-button type="primary" @click="handleSubmit"> 确定 </el-button>
                    </div>
                </template>
            </el-card>
        </el-col>

        <el-col :span="mainStore.userType == '管理员' ? 8 : 12">
            <el-card style="margin: 10px" shadow="never">
                <template #header>
                    <div class="card-header">
                        <span>修改密码</span>
                    </div>
                </template>
                <el-form ref="resetFormRef" :model="updatePwdFormData" label-width="80px" :rules="rules2">
                    <el-form-item label="用户名" prop="username">
                        <el-input v-model="mainStore.curuser.username" placeholder="请输入用户名" :disabled="true" />
                    </el-form-item>
                    <el-form-item label="旧密码" prop="oldpwd">
                        <el-input
                            v-model="updatePwdFormData.oldpwd"
                            placeholder="请输入旧密码"
                            type="password"
                            show-password
                        />
                    </el-form-item>
                    <el-form-item label="新密码" prop="newpwd">
                        <el-input
                            v-model="updatePwdFormData.newpwd"
                            placeholder="请输入新密码"
                            type="password"
                            show-password
                        />
                    </el-form-item>
                    <el-form-item label="确认密码" prop="newpwd2">
                        <el-input
                            v-model="updatePwdFormData.newpwd2"
                            placeholder="请输入确认密码"
                            type="password"
                            show-password
                        />
                    </el-form-item>
                </el-form>
                <template #footer>
                    <div style="text-align: center">
                        <el-button @click="handleRest">重置</el-button>
                        <el-button type="primary" @click="handleUpdatePwdSubmit"> 确定 </el-button>
                    </div>
                </template>
            </el-card>
        </el-col>
    </el-row>
</template>
<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                 .............................................
//                          佛祖保佑             永无BUG

import { onMounted, reactive, ref } from "vue"; // 导入 Vue 相关模块
import { ElForm, ElMessage, ElMessageBox } from "element-plus"; // 导入 Element Plus 组件
import request from "@/utils/request"; // 导入请求模块
import { useThrottleFn } from "@vueuse/core"; // 导入节流函数
import { Delete, Plus, RefreshRight } from "@element-plus/icons-vue"; // 导入 Element Plus 图标
import { useMainStore } from "@/utils/store.js"; // 导入主要的 store
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";

const mainStore = useMainStore();
const formRef = ref(ElForm); // 修改表单引用
const resetFormRef = ref(ElForm); // 修改密码表单引用
const updatePwdFormData = ref({}); // 密码
// 表单规则
const rules = reactive({
    userType: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    username: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    pwd: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    displayName: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    sex: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    age: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    phone: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    img: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});
const rules2 = reactive({
    // 表单校验规则
    oldpwd: [{ required: true, message: "请输入旧密码", trigger: "blur" }],
    newpwd: [{ required: true, message: "请输入新密码", trigger: "blur" }],
    newpwd2: [{ required: true, message: "请输入确认密码", trigger: "blur" }],
});

//重置
function handleRest() {
    resetFormRef.value.clearValidate();
    resetFormRef.value.resetFields();
}

// 提交
const handleSubmit = useThrottleFn(() => {
    formRef.value.validate((valid) => {
        if (valid) {
            let url = "/api/sysUser/add";
            if (mainStore.curuser.id) {
                url = "/api/sysUser/update";
            }
            request({
                url: url,
                data: mainStore.curuser,
            }).then(() => {
                ElMessage({
                    showClose: true,
                    message: "操作成功",
                    type: "success",
                });
                resetQuery();
            });
        }
    });
}, 500);

// 提交
const handleUpdatePwdSubmit = useThrottleFn(() => {
    resetFormRef.value.validate((valid) => {
        if (updatePwdFormData.value.newpwd != updatePwdFormData.value.newpwd2) {
            ElMessage({
                showClose: true,
                message: "两次密码不一致",
                type: "warning",
            });
            return;
        }
        if (valid) {
            request({
                url: "/api/updatePwd", // 修改请求的地址
                data: updatePwdFormData.value, // 修改后的用户数据
            }).then(() => {
                ElMessage({
                    showClose: true,
                    message: "操作成功",
                    type: "success",
                });
                updatePwdFormData.value = {};
            });
        }
    });
}, 500);

// 组件挂载完成后执行查询操作
onMounted(() => {});
</script>
<style scoped></style>
