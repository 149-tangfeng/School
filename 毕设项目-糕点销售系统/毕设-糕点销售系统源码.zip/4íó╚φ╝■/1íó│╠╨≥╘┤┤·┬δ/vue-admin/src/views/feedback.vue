<template>
    <div style="margin: 20px">
        <el-form ref="queryFormRef" :model="queryParams" :inline="true" @submit.prevent="handleQuery" v-if="showQuery">
            <el-form-item label="内容" prop="content">
                <el-input v-model="queryParams.content" placeholder="内容" clearable style="width: 200px" />
            </el-form-item>

            <el-form-item>
                <el-button type="primary" @click="handleQuery">
                    <el-icon>
                        <Search />
                    </el-icon>
                    搜索
                </el-button>
                <el-button @click="resetQuery">
                    <el-icon>
                        <RefreshRight />
                    </el-icon>
                    重置
                </el-button>
                <el-button type="danger" :disabled="removeIds.length === 0" @click="handleDelete()">
                    <el-icon>
                        <Delete />
                    </el-icon>
                    删除
                </el-button>
            </el-form-item>
        </el-form>
    </div>

    <div style="margin: 20px">
        <el-table v-if="mainStore.userType == '管理员'" v-loading="loading" :data="pageDataList"
            @selection-change="handleSelectionChange"
            :header-cell-style="{ background: '#f8f8f9', color: '#606266', height: '50px' }">
            <el-table-column type="selection" width="50" align="center" />
            <el-table-column label="用户" align="center" prop="ext.user.displayName" />
            <el-table-column label="内容" align="center" prop="content" show-overflow-tooltip />
            <el-table-column label="回复" align="center" prop="reply" show-overflow-tooltip />
            <el-table-column label="精选" align="center" prop="feedbackStatus" />
            <el-table-column label="创建时间" align="center" prop="createTime" />
            <el-table-column label="操作" align="center" fixed="right" width="220">
                <template #default="scope">
                    <el-button type="primary" link size="small" v-if="!scope.row.reply" @click="openDialog(scope.row)">
                        回复
                    </el-button>
                    <el-button type="primary" link size="small" v-if="!!scope.row.reply && !scope.row.feedbackStatus"
                        @click="handleUpdate(scope.row)">
                        精选
                    </el-button>
                </template>
            </el-table-column>
        </el-table>

        <div v-if="mainStore.userType != '管理员'">
            <el-card shadow="never" v-for="item in pageDataList" style="margin-top: 10px">
                <div style="padding: 10px; display: flex; align-items: center; gap: 10px">
                    <el-tag type="success" v-if="item.feedbackStatus == '精选'">精选</el-tag>
                    <div style="font-size: small; color: gray">{{ item.createTime }}</div>
                </div>
                <div style="padding: 10px">{{ item.ext.user.displayName }}: {{ item.content }}</div>
                <div style="padding: 10px">回复 : {{ item.reply }}</div>
            </el-card>

            <!-- 发布评论区域 -->
            <el-card shadow="never" style="margin-top: 10px">
                <div style="padding: 10px">
                    <el-form ref="formRef" :model="formData" label-width="80px">
                        <el-form-item label="评论内容">
                            <el-input v-model="formData.content" placeholder="请输入评论内容" type="textarea" :autosize="{ minRows: 3 }"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="handleSubmit">发布评论</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-card>
        </div>

        <div style="display: flex; justify-content: flex-end; background-color: white">
            <pagination v-show="total > 0" :total="total" v-model:page="queryParams.pageNum"
                v-model:limit="queryParams.pageSize" @pagination="handleQuery" />
        </div>
    </div>

    <el-dialog v-model="dialog" :title="!formData.id ? '新增' : '编辑'" width="600px" append-to-body @close="closeDialog">
        <!-- 新增/编辑 -->
        <el-form ref="formRef" :model="formData" label-width="80px" :rules="rules">
            <el-form-item label="内容" prop="content" v-if="mainStore.userType != '管理员'">
                <el-input v-model="formData.content" placeholder="内容" type="textarea" :autosize="{ minRows: 3 }" />
            </el-form-item>
            <el-form-item label="回复" prop="reply" v-if="mainStore.userType == '管理员'">
                <el-input v-model="formData.reply" placeholder="回复" type="textarea" :autosize="{ minRows: 3 }" />
            </el-form-item>
        </el-form>
        <template #footer>
            <div>
                <el-button @click="closeDialog"> 取消 </el-button>
                <el-button type="primary" @click="handleSubmit"> 确定 </el-button>
            </div>
        </template>
    </el-dialog>
</template>

<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                   .............................................
//                            佛祖保佑             永无BUG

import { computed, onMounted, reactive, ref } from "vue";
import { ElForm, ElMessage, ElMessageBox } from "element-plus";
import request from "@/utils/request";
import { useThrottleFn } from "@vueuse/core";
import { Delete, Plus, RefreshRight, ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";
import setting from "@/utils/setting.js";

const mainStore = useMainStore();
const showQuery = computed(() => {
    if (mainStore.userType == "管理员") {
        return true;
    } else if (mainStore.userType == "用户") {
        return false;
    }
    return true;
});
// 查询表单的引用
const queryFormRef = ref(ElForm);
// 表单的引用
const formRef = ref(ElForm);
// 数据总数
const total = ref(0);
// 分页数据列表
const pageDataList = ref([]);
// 对话框的可见性控制
const dialog = ref(false);
// 加载状态控制
const loading = ref(false);
// 删除操作选择的项的 ID 列表
const removeIds = ref([]);
// 选项
const options = ref([]);
// 表单的数据
const formData = reactive({});
const commentForm = reactive({});
// 查询参数
const queryParams = reactive({
    pageNum: 1,
    pageSize: 10,
});

// 表单规则
const rules = reactive({
    userId: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    content: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    reply: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    feedbackStatus: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});

//打开对话框
function openDialog(row) {
    dialog.value = true;
    if (row) {
        Object.assign(formData, { ...row });
    }
}
//关闭对话框，并重置表单
function closeDialog() {
    dialog.value = false;
    formRef.value.resetFields();
    formRef.value.clearValidate();
    setting.clearFormData(formData);
}
//处理行选择变化事件
function handleSelectionChange(selection) {
    removeIds.value = selection.map((item) => item.id);
}
//详情
function openDetail(row) {
    mainStore.tmpData = row;
    router.push("/feedbackDetail");
}
//重置查询条件，并执行查询
function resetQuery() {
    queryFormRef.value.resetFields();
    queryParams.pageNum = 1;
    handleQuery();
}
//执行查询操作
const handleQuery = useThrottleFn(() => {
    loading.value = true;
    request({
        url: "/api/feedback/page",
        data: queryParams,
    })
        .then(({ data }) => {
            pageDataList.value = data.list;
            total.value = data.total;
        })
        .finally(() => {
            loading.value = false;
        });
});
//执行删除操作
const handleDelete = useThrottleFn((row) => {
    if (row) {
        removeIds.value = [row.id];
    }
    if (removeIds.value.length === 0) {
        ElMessage({
            showClose: true,
            message: "请勾选删除项",
            type: "warning",
        });
        return;
    }

    ElMessageBox.confirm("确认删除?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
    }).then(function () {
        request({
            url: "/api/feedback/delete",
            data: {
                ids: removeIds.value,
            },
        }).then(() => {
            ElMessage({
                showClose: true,
                message: "操作成功",
                type: "success",
            });
            removeIds.value = [];
            resetQuery();
        });
    });
});
// 提交
const handleSubmit = useThrottleFn(() => {
    formRef.value.validate((valid) => {
        if (valid) {
            let url = "/api/feedback/add";
            if (formData.id) {
                url = "/api/feedback/update";
            }
            request({
                url: url,
                data: formData,
            }).then(() => {
                ElMessage({
                    showClose: true,
                    message: "操作成功",
                    type: "success",
                });
                closeDialog();
                resetQuery();
            });
        }
    });
}, 500);
// 提交
const handleUpdate = useThrottleFn((row) => {
    ElMessageBox.confirm("确认操作?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
    }).then(function () {
        request({
            url: "/api/feedback/update",
            data: {
                id: row.id,
                feedbackStatus: "精选",
            },
        }).then(() => {
            ElMessage({
                showClose: true,
                message: "操作成功",
                type: "success",
            });
            resetQuery();
        });
    });
}, 500);
// 下拉列表
function listOptions() {
    request({
        url: "",
        data: {},
    }).then(({ data }) => {
        options.value = data;
    });
}

//组件挂载时执行初始化查询
onMounted(() => {
    handleQuery();
});
</script>

<style scoped></style>
