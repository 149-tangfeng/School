<template>
    <div style="margin: 20px">
        <el-form ref="queryFormRef" :model="queryParams" :inline="true" @submit.prevent="handleQuery" v-if="showQuery">
            <el-form-item style="margin-bottom: 0">
                <el-button type="primary" @click="handleQuery">
                    <el-icon>
                        <Search />
                    </el-icon>
                    搜索
                </el-button>
                <el-button @click="resetQuery">
                    <el-icon>
                        <RefreshRight />
                    </el-icon>
                    重置
                </el-button>
                <el-button type="success" @click="openDialog()">
                    <el-icon>
                        <Plus />
                    </el-icon>
                    新增
                </el-button>
                <el-button type="danger" :disabled="removeIds.length === 0" @click="handleDelete()">
                    <el-icon>
                        <Delete />
                    </el-icon>
                    删除
                </el-button>
            </el-form-item>
        </el-form>
    </div>

    <div style="margin: 20px">
        <el-table
            v-loading="loading"
            :data="pageDataList"
            :header-cell-style="{ background: '#f8f8f9', color: '#606266', height: '50px' }"
        >
            <el-table-column label="糕点" align="center" prop="ext.data.treasureName">
                <template #default="scope">
                    <el-button type="primary" link @click="openDetail(scope.row)">
                        {{ scope.row.ext.data.name }}
                    </el-button>
                </template>
            </el-table-column>
            <el-table-column label="收藏时间" align="center" prop="createTime" />
        </el-table>

        <div style="display: flex; justify-content: flex-end; background-color: white">
            <pagination
                v-show="total > 0"
                :total="total"
                v-model:page="queryParams.pageNum"
                v-model:limit="queryParams.pageSize"
                @pagination="handleQuery"
            />
        </div>
    </div>

    <el-dialog
        v-model="dialog"
        :title="!formData.id ? '新增' : '编辑'"
        width="600px"
        append-to-body
        @close="closeDialog"
    >
        <!-- 新增/编辑 -->
        <el-form ref="formRef" :model="formData" label-width="80px" :rules="rules">
            <el-form-item label="用户" prop="userId">
                <el-input v-model="formData.userId" placeholder="用户" />
            </el-form-item>
            <el-form-item label="关联数据" prop="dataId">
                <el-input v-model="formData.dataId" placeholder="关联数据" />
            </el-form-item>
        </el-form>
        <template #footer>
            <div>
                <el-button @click="closeDialog"> 取消 </el-button>
                <el-button type="primary" @click="handleSubmit"> 确定 </el-button>
            </div>
        </template>
    </el-dialog>

    <el-dialog v-model="dialog2" title="详情" width="1000px" append-to-body @close="closeDialog2">
        <div v-html="html"></div>
    </el-dialog>
</template>

<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                   .............................................
//                            佛祖保佑             永无BUG

import { computed, onMounted, reactive, ref } from "vue";
import { ElForm, ElMessage, ElMessageBox } from "element-plus";
import request from "@/utils/request";
import { useThrottleFn } from "@vueuse/core";
import { Delete, Plus, RefreshRight, ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";
import setting from "@/utils/setting.js";

const mainStore = useMainStore();
const showQuery = computed(() => {
    if (mainStore.curuser.userType == "管理员") {
        return true;
    } else if (mainStore.curuser.userType == "用户") {
        return false;
    }
    return false;
});
// 查询表单的引用
const queryFormRef = ref(ElForm);
// 表单的引用
const formRef = ref(ElForm);
// 数据总数
const total = ref(0);
// 分页数据列表
const pageDataList = ref([]);
// 对话框的可见性控制
const dialog = ref(false);
// 加载状态控制
const loading = ref(false);
// 删除操作选择的项的 ID 列表
const removeIds = ref([]);
// 选项
const options = ref([]);
// 表单的数据
const formData = reactive({});
// 查询参数
const queryParams = reactive({
    pageNum: 1,
    pageSize: 10,
});
const dialog2 = ref(false);
const html = ref("");
// 表单规则
const rules = reactive({
    userId: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    dataId: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});

//打开对话框
function openDialog(row) {
    dialog.value = true;
    if (row) {
        Object.assign(formData, { ...row });
    }
}

//关闭对话框，并重置表单
function closeDialog() {
    dialog.value = false;
    formRef.value.resetFields();
    formRef.value.clearValidate();
    setting.clearFormData(formData);
}

//打开对话框
function openDialog2(row) {
    dialog2.value = true;
    html.value = row.content;
}

//关闭对话框，并重置表单
function closeDialog2() {
    dialog2.value = false;
    html.value = "";
}

//处理行选择变化事件
function handleSelectionChange(selection) {
    removeIds.value = selection.map((item) => item.id);
}

//详情
function openDetail(row) {
    mainStore.tmpData = row.ext.data;
    router.push("/cakeDetail");
}

//重置查询条件，并执行查询
function resetQuery() {
    queryFormRef.value.resetFields();
    queryParams.pageNum = 1;
    handleQuery();
}

//执行查询操作
const handleQuery = useThrottleFn(() => {
    loading.value = true;
    request({
        url: "/api/bookmark/page",
        data: queryParams,
    })
        .then(({ data }) => {
            pageDataList.value = data.list;
            total.value = data.total;
        })
        .finally(() => {
            loading.value = false;
        });
});
//执行删除操作
const handleDelete = useThrottleFn((row) => {
    if (row) {
        removeIds.value = [row.id];
    }
    if (removeIds.value.length === 0) {
        ElMessage({
            showClose: true,
            message: "请勾选删除项",
            type: "warning",
        });
        return;
    }

    ElMessageBox.confirm("确认删除?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
    }).then(function () {
        request({
            url: "/api/bookmark/delete",
            data: {
                ids: removeIds.value,
            },
        }).then(() => {
            ElMessage({
                showClose: true,
                message: "操作成功",
                type: "success",
            });
            removeIds.value = [];
            resetQuery();
        });
    });
});
// 提交
const handleSubmit = useThrottleFn(() => {
    formRef.value.validate((valid) => {
        if (valid) {
            let url = "/api/bookmark/add";
            if (formData.id) {
                url = "/api/bookmark/update";
            }
            request({
                url: url,
                data: formData,
            }).then(() => {
                ElMessage({
                    showClose: true,
                    message: "操作成功",
                    type: "success",
                });
                closeDialog();
                resetQuery();
            });
        }
    });
}, 500);

// 下拉列表
function listOptions() {
    request({
        url: "",
        data: {},
    }).then(({ data }) => {
        options.value = data;
    });
}

//组件挂载时执行初始化查询
onMounted(() => {
    handleQuery();
});
</script>

<style scoped></style>
