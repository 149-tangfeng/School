<template>
    <!-- 导航栏 -->
    <div class="navbar">
        <div class="login-text">
            <span>您好，请</span>
            <router-link to="/login" class="login-link">登录</router-link>
        </div>
    </div>

    <div class="home">
        <div style="margin: 20px">
            <el-carousel height="350px">
                <el-carousel-item v-for="item in bannerList" :key="item">
                    <img :src="item.img" style="object-fit: cover; width: 100%" />
                </el-carousel-item>
            </el-carousel>
        </div>

        <div style="margin: 20px;background-color: white;">
            <div style="display: flex; justify-content: space-between;">
                <h2 style="font-size: 24px;margin-left: 10px;">新闻公告</h2>
            </div>
            <el-table v-loading="loading" :data="pageDataList" style="height: 350px;"
                :header-cell-style="{ background: '#f4f4f4', color: '#606266', height: '50px' }">
                <el-table-column label="标题" prop="title">
                    <template #default="scope">
                        <el-button type="primary" link @click="openDialog2(scope.row)"> {{ scope.row.title }}
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="发布时间" prop="createTime" />
            </el-table>
        </div>
    </div>

    <el-dialog v-model="dialog2" :title="dialogTitle" style="max-width: 100%; text-align: center;" append-to-body @close="closeDialog2">
        <div v-html="html"></div>
    </el-dialog>

</template>

<script setup>
import { computed, onMounted, reactive, ref, nextTick } from "vue";
import { ElForm, ElMessage, ElMessageBox } from "element-plus";
import request from "@/utils/request";
import { useThrottleFn } from "@vueuse/core";
import { Delete, Plus, RefreshRight, ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";
import setting from "@/utils/setting.js";

const mainStore = useMainStore();


// 数据总数
const total = ref(0);
// 分页数据列表
const pageDataList = ref([]);
// banner列表
const bannerList = ref([]);
// 加载状态控制
const loading = ref(false);
// 对话框标题
const dialogTitle = ref("");
// 查询参数
const queryParams = reactive({
    pageNum: 1,
    pageSize: 100,
});
const dialog2 = ref(false);
const html = ref("");

//打开对话框
function openDialog2(row) {
    dialog2.value = true;
    html.value = row.content;
    dialogTitle.textContent = row.title; // Assuming dialogTitle is the element representing the title of the dialog
    nextTick(() => {
        const images = document.querySelectorAll('.el-dialog img');
        images.forEach(image => {
            image.style.maxWidth = '100%';
            image.style.height = 'auto';
        });
    });
}
//关闭对话框，并重置表单
function closeDialog2() {
    dialog2.value = false;
    html.value = "";
}

//执行查询操作
const handleQuery = useThrottleFn(() => {
    loading.value = true;
    request({
        url: "/api/notice/page",
        data: queryParams,
    })
        .then(({ data }) => {
            pageDataList.value = data.list;
            total.value = data.total;
        })
        .finally(() => {
            loading.value = false;
        });
});
//执行查询操作
const handleQueryBanner = useThrottleFn(() => {
    request({
        url: "/api/banner/list",
        data: {},
    }).then(({ data }) => {
        bannerList.value = data;
    });
});

//组件挂载时执行初始化查询
onMounted(() => {
    handleQuery();
    handleQueryBanner();
});
</script>

<style scoped>
.home {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
}

.navbar {
    height: 60px;
    background-color: #2d3748;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: center;
    align-items: center;
}

.login-text {
    color: #fff;
}

.login-link {
    color: #ffd04b;
    text-decoration: underline;
    cursor: pointer;
}
</style>
