<template>
    <el-card style="margin:10px">
        <el-row :gutter="16">
            <el-col :span="8">
                <div class="statistic-card">
                    <el-statistic :value="userCount">
                        <template #title>
                            <div style="display: inline-flex; align-items: center">
                                用户数量
                                <el-tooltip effect="dark" content="" placement="top">
                                    <el-icon style="margin-left: 4px" :size="12">
                                        <Warning />
                                    </el-icon>
                                </el-tooltip>
                            </div>
                        </template>
                    </el-statistic>
                    <div class="statistic-footer">
                        <div class="footer-item">
                            <span>较昨日</span>
                            <span :class="userIncrease <= 0 ? 'green' : 'red'">
                                {{ userIncrease }}
                                <el-icon>
                                    <CaretTop v-if="userIncrease > 0" />
                                    <CaretBottom v-else-if="userIncrease <= 0" />

                                </el-icon>
                            </span>
                        </div>
                    </div>
                </div>
            </el-col>
            <el-col :span="8">
                <div class="statistic-card">
                    <el-statistic :value="orderCount">
                        <template #title>
                            <div style="display: inline-flex; align-items: center">
                                订单数量
                                <el-tooltip effect="dark" content="当前订单数量" placement="top">
                                    <el-icon style="margin-left: 4px" :size="12">
                                        <Warning />
                                    </el-icon>
                                </el-tooltip>
                            </div>
                        </template>
                    </el-statistic>
                    <div class="statistic-footer">
                        <div class="footer-item">
                            <span>较昨日</span>
                            <span :class="orderIncrease <= 0 ? 'green' : 'red'">
                                {{ orderIncrease }}
                                <el-icon>
                                    <CaretTop v-if="orderIncrease > 0" />
                                    <CaretBottom v-else-if="orderIncrease <= 0" />

                                </el-icon>
                            </span>
                        </div>
                    </div>
                </div>
            </el-col>
            <el-col :span="8">
                <div class="statistic-card">
                    <el-statistic :value="commentCount" title="评论数量">
                        <template #title>
                            <div style="display: inline-flex; align-items: center">
                                评论数量
                            </div>
                        </template>
                    </el-statistic>
                    <div class="statistic-footer">
                        <div class="footer-item">
                            <span>较昨日</span>
                            <span :class="commentIncrease <= 0 ? 'green' : 'red'">
                                {{ commentIncrease }}
                                <el-icon>
                                    <CaretTop v-if="commentIncrease > 0" />
                                    <CaretBottom v-else-if="commentIncrease <= 0" />

                                </el-icon>
                            </span>
                        </div>
                        <div class="footer-item">
                            <el-icon :size="14">
                                <ArrowRight />
                            </el-icon>
                        </div>
                    </div>
                </div>
            </el-col>
        </el-row>
    </el-card>
    <el-card style="margin:10px">
        <el-row :gutter="10">
            <el-col :span="12">
                <el-card>
                    <div id="main1" style="height:400px;"></div>
                </el-card>
            </el-col>
            <el-col :span="12">
                <el-card>
                    <div id="main3" style="height:400px;"></div>
                </el-card>
            </el-col>
        </el-row>
    </el-card>
</template>

<script setup>
import request from "@/utils/request.js";
import {
    ArrowRight,
    CaretBottom,
    CaretTop,
    Warning,
} from "@element-plus/icons-vue";
import * as echarts from "echarts";
import { onMounted, ref } from "vue";

const userCount = ref(0);
const userIncrease = ref(0);
const orderCount = ref(0);
const orderIncrease = ref(0);
const commentCount = ref(0);
const commentIncrease = ref(0);
const cates = ref([]);
const salesDataByCate = ref([]);
const salesDataByProduct = ref([]);

function init() {
    // 基于准备好的 dom，初始化 echarts 实例
    const Chart1 = echarts.init(document.getElementById("main1"));
    const Chart3 = echarts.init(document.getElementById("main3"));

    try {

        request({
            url: "/api/statistics/analysis", // 修改请求的地址
            data: {},
        }).then((res) => {
            console.log(res.data);

            userCount.value = res.data.userCount;
            userIncrease.value = res.data.userIncrease;
            orderCount.value = res.data.orderCount;
            orderIncrease.value = res.data.orderIncrease;
            commentCount.value = res.data.commentCount;
            commentIncrease.value = res.data.commentIncrease;


            cates.value = res.data.salesDataByCate.map(item => Object.keys(item)[0]);
            salesDataByCate.value = res.data.salesDataByCate.map(item => Object.values(item)[0]);

            salesDataByProduct.value = res.data.salesDataByProduct.map(item => {
                const name = Object.keys(item)[0];
                const value = item[name];
                return { name, value };
            });;

            // 绘制图表
            const options1 = {
                title: {
                    text: "分类销量",
                    subtext: '根据蛋糕的分类进行销量统计',
                },
                tooltip: {
                    trigger: "axis",
                },
                xAxis: {
                    data: cates.value,
                },
                yAxis: {},
                series: [
                    {
                        name: "销量",
                        type: "bar",
                        data: salesDataByCate.value,
                    },
                ],
            };

            const options3 = {
                title: {
                    text: "单品销量",
                    subtext: '根据蛋糕的单品进行销量统计',
                },
                tooltip: {
                    trigger: 'item', // 鼠标悬停时显示提示框
                    formatter: '{a} <br/>{b}: {c} ({d}%)', // 提示框内容格式
                },
                series: [
                    {
                        name: '销量',
                        type: 'pie',
                        radius: [20, 140],
                        center: ['50%', '50%'],
                        roseType: 'area',
                        itemStyle: {
                            borderRadius: 5
                        },
                        data: salesDataByProduct.value,
                    }
                ],

            };

            // 渲染图表
            Chart1.setOption(options1);
            Chart3.setOption(options3);
        });
    } catch (error) {
        console.error("Failed to fetch statistics:", error);
    }
};

onMounted(() => {
    init();
});

</script>

<style scoped>
.el-statistic {
    --el-statistic-content-font-size: 28px;
}

.statistic-card {
    height: 100%;
    padding: 20px;
    border-radius: 4px;
    background-color: var(--el-bg-color-overlay);
}

.statistic-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    font-size: 12px;
    color: var(--el-text-color-regular);
    margin-top: 16px;
}

.statistic-footer .footer-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.statistic-footer .footer-item span:last-child {
    display: inline-flex;
    align-items: center;
    margin-left: 4px;
}

.green {
    color: var(--el-color-success);
}

.red {
    color: var(--el-color-error);
}
</style>