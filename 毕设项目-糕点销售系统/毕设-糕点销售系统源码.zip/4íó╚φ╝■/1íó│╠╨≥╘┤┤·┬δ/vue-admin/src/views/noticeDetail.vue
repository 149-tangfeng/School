<template>
    <div style="margin: 20px">
        <div style="text-align: center">
            <h2>{{ mainStore.tmpData.title }}</h2>
        </div>
        <div v-html="mainStore.tmpData.content"></div>
    </div>
    <div style="height: 20px"></div>
</template>

<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                   .............................................
//                            佛祖保佑             永无BUG

import { computed, onMounted, reactive, ref } from "vue";
import { ElForm, ElMessage, ElMessageBox } from "element-plus";
import request from "@/utils/request";
import { useThrottleFn } from "@vueuse/core";
import { Delete, Plus, RefreshRight, ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";
import setting from "@/utils/setting.js";

const mainStore = useMainStore();

//组件挂载时执行初始化查询
onMounted(() => {});
</script>

<style scoped></style>
