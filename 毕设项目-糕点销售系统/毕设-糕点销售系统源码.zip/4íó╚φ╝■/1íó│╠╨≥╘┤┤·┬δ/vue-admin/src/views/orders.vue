<template>
  <div style="margin: 20px">
    <el-form ref="queryFormRef" :model="queryParams" :inline="true" @submit.prevent="handleQuery" v-if="showQuery">
      <el-form-item label="糕点名" prop="cakeName">
        <el-input v-model="queryParams.cakeName" placeholder="糕点名" clearable style="width: 200px" />
      </el-form-item>


      <el-form-item>
        <el-button type="primary" @click="handleQuery">
          <el-icon>
            <Search />
          </el-icon>
          搜索
        </el-button>
        <el-button @click="resetQuery">
          <el-icon>
            <RefreshRight />
          </el-icon>
          重置
        </el-button>
        <el-button type="success" @click="openDialog()" v-if="mainStore.userType == '管理员'">
          <el-icon>
            <Plus />
          </el-icon>
          新增
        </el-button>
        <el-button type="danger" :disabled="removeIds.length === 0" @click="handleDelete()"
          v-if="mainStore.userType == '管理员'">
          <el-icon>
            <Delete />
          </el-icon>
          删除
        </el-button>
      </el-form-item>
    </el-form>
  </div>

  <div style="margin: 20px" v-if="mainStore.userType == '管理员'">

    <el-table v-loading="loading" :data="pageDataList" @selection-change="handleSelectionChange"
      :header-cell-style="{ background: '#f8f8f9', color: '#606266', height: '50px' }">
      <el-table-column type="selection" width="50" align="center" />
      <el-table-column label="用户" align="center" prop="createBy" />
      <el-table-column label="糕点ID" align="center" prop="cakeId" />
      <el-table-column label="糕点名" align="center" prop="cakeName" />
      <el-table-column label="单价" align="center" prop="price" />
      <el-table-column label="数量" align="center" prop="quantity" />
      <el-table-column label="订单金额" align="center" prop="cost" />
      <el-table-column label="订单编号" align="center" prop="sn" />
      <el-table-column label="创建时间" align="center" prop="createTime" />
      <el-table-column label="操作" align="center" fixed="right" width="220">
        <template #default="scope">
          <el-button type="primary" link size="small" @click="openDialog(scope.row)">
            编辑
          </el-button>
        </template>
      </el-table-column>
    </el-table>


  </div>


  <div style="margin: 20px" v-if="mainStore.userType !== '管理员'">
    <el-row :gutter="20">
      <el-col :span="24" v-for="order in pageDataList" :key="order.id"
        style="margin-top: 20px; border:1px solid #e4e4e4; padding: 20px;">
        <el-container>
          <el-header style="display: flex; justify-content: space-between; font-size: 12px;">
            <span>订单编号: {{ order.sn }}</span>
            <span>下单时间：{{ order.createTime }}</span>
          </el-header>
          <el-container>
            <el-aside width="200px">
              <img :src="order.cake.img" alt="商品图片" style="width: 100%; height: 150px; object-fit: cover;">
            </el-aside>
            <el-container>
              <el-main>
                <div style="margin-top: 10px;">
                  <p style="font-size: 16px; font-weight: bold;">{{ order.cakeName }}</p>
                  <p style="color: #999;">单价: {{ order.price }}元/千克</p>
                  <p>订单金额: {{ order.cost.toFixed(2) }}元</p>
                </div>
              </el-main>
              <el-footer style="display: flex; justify-content: flex-end; align-items: center;">
                <el-button type="warning" size="mini" @click="openDialog3(order)">评论</el-button>
              </el-footer>
            </el-container>
          </el-container>
        </el-container>
      </el-col>
    </el-row>
  </div>


  <div style="display: flex; justify-content: flex-end; background-color: white">
    <pagination v-show="total > 0" :total="total" v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize" @pagination="handleQuery" />
  </div>


  <el-dialog v-model="dialog" :title="!formData.id ? '新增' : '编辑'" width="600px" append-to-body @close="closeDialog">
    <!-- 新增/编辑 -->
    <el-form ref="formRef" :model="formData" label-width="80px" :rules="rules">
      <el-form-item label="用户ID" prop="userId">
        <el-input v-model="formData.userId" placeholder="用户ID" />
      </el-form-item>
      <el-form-item label="糕点ID" prop="cakeId">
        <el-input v-model="formData.cakeId" placeholder="糕点ID" />
      </el-form-item>
      <el-form-item label="糕点名" prop="cakeName">
        <el-input v-model="formData.cakeName" placeholder="糕点名" />
      </el-form-item>
      <el-form-item label="单价" prop="price">
        <el-input v-model="formData.price" placeholder="单价" />
      </el-form-item>
      <el-form-item label="数量" prop="quantity">
        <el-input v-model="formData.quantity" placeholder="数量" />
      </el-form-item>
      <el-form-item label="订单金额" prop="cost">
        <el-input v-model="formData.cost" placeholder="订单金额" />
      </el-form-item>
      <el-form-item label="订单编号" prop="sn">
        <el-input v-model="formData.sn" placeholder="订单编号" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div>
        <el-button @click="closeDialog">
          取消
        </el-button>
        <el-button type="primary" @click="handleSubmit">
          确定
        </el-button>
      </div>
    </template>
  </el-dialog>

  <el-dialog v-model="dialog2" title="详情" width="1000px" append-to-body @close="closeDialog2">
    <div v-html="html"></div>
  </el-dialog>


  <el-dialog v-model="dialog3" :title="新增" width="600px" append-to-body @close="closeDialog3">
    <!-- 新增/编辑 -->
    <el-form ref="formRef2" :model="commentData" label-width="80px" :rules="rules2">
      <el-form-item label="评论内容" prop="content">
        <el-input v-model="commentData.content" placeholder="内容" type="textarea" :autosize="{ minRows: 5 }" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div>
        <el-button @click="closeDialog3"> 取消 </el-button>
        <el-button type="primary" @click="handleSendComment"> 发布 </el-button>
      </div>
    </template>
  </el-dialog>
  <div style="height: 20px"></div>
</template>

<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                   .............................................
//                            佛祖保佑             永无BUG

import { computed, onMounted, reactive, ref } from "vue";
import { ElForm, ElMessage, ElMessageBox } from "element-plus";
import request from "@/utils/request";
import { useThrottleFn } from "@vueuse/core";
import { Delete, Plus, RefreshRight, ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";
import setting from "@/utils/setting.js";

const mainStore = useMainStore();
const showQuery = computed(() => {
  if (mainStore.curuser.userType == "管理员") {
    return true;
  } else if (mainStore.curuser.userType == "用户") {
    return true;
  }
  return false;
});

let queryUserId = null;
if (mainStore.curuser.userType == "用户") {
  queryUserId = mainStore.curuser.id;
}
// 查询参数
const queryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  userId: queryUserId,
});

// 查询表单的引用
const queryFormRef = ref(ElForm);
// 表单的引用
const formRef = ref(ElForm);
const formRef2 = ref(ElForm);
// 数据总数
const total = ref(0);
// 分页数据列表
const pageDataList = ref([]);
// 对话框的可见性控制
const dialog = ref(false);
// 加载状态控制
const loading = ref(false);
// 删除操作选择的项的 ID 列表
const removeIds = ref([]);
// 选项
const options = ref([]);
// 表单的数据
const formData = reactive({});
const commentData = reactive({});

const dialog2 = ref(false);
const dialog3 = ref(false);
const html = ref("");
// 表单规则
const rules = reactive({
  userId: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  cakeId: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  cakeName: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  price: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  quantity: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  cost: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  sn: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
  delFlag: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});
const rules2 = reactive({
  content: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});

//打开对话框
function openDialog(row) {
  dialog.value = true;
  if (row) {
    Object.assign(formData, { ...row });
  }
}
//关闭对话框，并重置表单
function closeDialog() {
  dialog.value = false;
  formRef.value.resetFields();
  formRef.value.clearValidate();
  setting.clearFormData(formData);
}
//打开对话框
function openDialog2(row) {
  dialog2.value = true;
  html.value = row.content;
}
//关闭对话框，并重置表单
function closeDialog2() {
  dialog2.value = false;
  html.value = "";
}

//打开对话框
function openDialog3(row) {
  dialog3.value = true;
  commentData.dataId = row.cake.id;
  commentData.userId = mainStore.curuser.id;

}
//关闭对话框，并重置表单
function closeDialog3() {
  dialog3.value = false;
  commentData.content = "";
}

//处理行选择变化事件
function handleSelectionChange(selection) {
  removeIds.value = selection.map((item) => item.id);
}
//详情
function openDetail(row) {
  mainStore.tmpData = row;
  router.push("/ordersDetail");
}
//重置查询条件，并执行查询
function resetQuery() {
  queryFormRef.value.resetFields();
  queryParams.pageNum = 1;
  handleQuery();
}
//执行查询操作
const handleQuery = useThrottleFn(() => {
  loading.value = true;
  request({
    url: "/api/orders/page",
    data: queryParams,
  }).then(({ data }) => {
    pageDataList.value = data.list;
    total.value = data.total;
  })
    .finally(() => {
      loading.value = false;
    });
});
//执行删除操作
const handleDelete = useThrottleFn((row) => {
  if (row) {
    removeIds.value = [row.id];
  }
  if (removeIds.value.length === 0) {
    ElMessage({
      showClose: true,
      message: "请勾选删除项",
      type: "warning",
    });
    return;
  }

  ElMessageBox.confirm("确认删除?", "警告", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(function () {
    request({
      url: "/api/orders/delete",
      data: {
        ids: removeIds.value,
      },
    }).then(() => {
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      });
      removeIds.value = [];
      resetQuery();
    });
  });
})
// 提交
const handleSubmit = useThrottleFn(() => {
  formRef.value.validate((valid) => {
    if (valid) {
      let url = "/api/orders/add";
      if (formData.id) {
        url = "/api/orders/update";
      }
      request({
        url: url,
        data: formData,
      }).then(() => {
        ElMessage({
          showClose: true,
          message: "操作成功",
          type: "success",
        });
        closeDialog();
        resetQuery();
      });
    }
  });
}, 500);

// 发布评论
const handleSendComment = useThrottleFn(() => {
  formRef2.value.validate((valid) => {
    if (valid) {
      let url = "/api/comments/add";
      request({
        url: url,
        data: commentData,
      }).then(() => {
        ElMessage({
          showClose: true,
          message: "操作成功",
          type: "success",
        });
        closeDialog3();
      });
    }
  });
}, 500);
// 下拉列表
function listOptions() {
  request({
    url: "",
    data: {},
  }).then(({ data }) => {
    options.value = data;
  });
}

//组件挂载时执行初始化查询
onMounted(() => {
  handleQuery();
});
</script>

<style scoped></style>
