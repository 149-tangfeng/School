<template>
    <el-config-provider :locale="locale">
        <div class="background">
            <div class="container">
                <div class="centered-div">
                    <el-card>
                        <template #header>
                            <div>注册</div>
                        </template>
                        <!-- 新增/编辑 -->
                        <el-form ref="formRef" :model="formData" label-width="80px" :rules="rules">
                            <el-form-item label="用户名" prop="username">
                                <el-input v-model="formData.username" placeholder="用户名" />
                            </el-form-item>
                            <el-form-item label="密码" prop="pwd">
                                <el-input v-model="formData.pwd" placeholder="密码" type="password" show-password />
                            </el-form-item>
                            <el-form-item label="姓名" prop="displayName">
                                <el-input v-model="formData.displayName" placeholder="姓名" />
                            </el-form-item>
                            <el-form-item label="性别" prop="sex">
                                <el-select v-model="formData.sex" placeholder="请选择">
                                    <el-option
                                        v-for="item in dict.sex"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value"
                                    />
                                </el-select>
                            </el-form-item>
                            <el-form-item label="年龄" prop="age">
                                <el-input v-model="formData.age" placeholder="年龄" type="number" />
                            </el-form-item>
                            <el-form-item label="手机号" prop="phone">
                                <el-input v-model="formData.phone" placeholder="手机号" />
                            </el-form-item>
                            <el-form-item label="头像" prop="img">
                                <image-upload v-model="formData.img" :limit="1"></image-upload>
                            </el-form-item>
                        </el-form>
                        <template #footer>
                            <div style="text-align: center">
                                <el-button @click="router.push('/login')">返回登录</el-button>
                                <el-button type="primary" @click="handleSubmit"> 确定 </el-button>
                            </div>
                        </template>
                    </el-card>
                </div>
            </div>
        </div>
    </el-config-provider>
</template>

<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                 .............................................
//                          佛祖保佑             永无BUG

import { zhCn } from "element-plus/es/locale/index";
import { onMounted, reactive, ref } from "vue";
import { ElForm, ElMessage, ElMessageBox } from "element-plus";
import request from "@/utils/request";
import { useThrottleFn } from "@vueuse/core";
import { Delete, Plus, RefreshRight, ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import dict from "@/utils/dict.js";
import setting from "@/utils/setting.js";

const mainStore = useMainStore(); // 获取 main store 实例
const formRef = ref(ElForm); // 添加表单引用
//表单数据
const formData = reactive({
    userType: "用户",
});
// 表单规则
const rules = reactive({
    userType: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    username: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    pwd: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    displayName: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    sex: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    age: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    phone: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
    img: [{ required: true, message: "必填项不能为空", trigger: "blur" }],
});
// 添加表单数据
const options = ref([]);
const locale = zhCn;

function resetForm() {
    formRef.value.resetFields();
    formRef.value.clearValidate();
}

// 提交
const handleSubmit = useThrottleFn(() => {
    formRef.value.validate((valid) => {
        if (valid) {
            let url = "/reg";
            request({
                url: url,
                data: formData,
            }).then(() => {
                ElMessage({
                    showClose: true,
                    message: "操作成功",
                    type: "success",
                });
                resetForm();
            });
        }
    });
}, 500);
</script>

<style scoped>
.background {
    background-image: url("/bg2.png"); /* 设置背景图片路径 */
    background-size: cover; /* 让背景图片覆盖整个屏幕 */
    background-position: center; /* 将背景图片居中 */
    height: 100vh; /* 使容器占据整个视口的高度 */
}

.container {
    display: flex;
    justify-content: center; /* 在主轴上居中 */
    align-items: center; /* 在交叉轴上居中 */
    height: 100vh; /* 使容器占据整个视口的高度 */
}

.centered-div {
    width: 600px; /* 宽度为600像素 */
}
</style>
