<template>
    <div v-if="userType == '管理员'">
        <!--左-->
        <div style="
                position: fixed;
                width: 200px;
                height: 60px;
                top: 0;
                left: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                text-align: center;
                background-color: #2d3748;
                border-right: solid 1px var(--el-menu-border-color);
                box-sizing: border-box;
                z-index: 999;
            ">
            <img src="/vite.svg" style="width: 25px; height: 25px" />
            <span style="color: white; margin-left: 5px; font-weight: bold; font-size: 14px">{{ setting.title }}</span>
        </div>

        <el-menu :default-active="active"
            style="width: 200px; margin-top: 60px; height: calc(100vh - 60px); overflow-y: auto"
            active-text-color="#ffd04b" background-color="#304156" text-color="#fff" class="menu">
            <el-menu-item v-for="item in setting.getMenu()" :index="item.path" @click="selectMenu(item.path)">
                <span>{{ item.name }}</span>
            </el-menu-item>
        </el-menu>

        <!--顶-->
        <div style="
                background-color: white;
                border-bottom: 1px solid #e4e7ed;
                width: calc(100vw - 200px);
                height: 60px;
                position: fixed;
                top: 0;
                left: 200px;
                box-sizing: border-box;
                display: flex;
                justify-content: flex-end;
                align-items: center;
            ">
            <el-dropdown style="height: 60px">
                <span class="el-dropdown-link" style="
                        color: var(--el-color-primary);
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        margin-right: 20px;
                    ">
                    {{ mainStore.curuser.displayName }}
                    <span>（{{ mainStore.userType }}）</span>
                    <el-icon class="el-icon--right">
                        <arrow-down />
                    </el-icon>
                </span>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item @click="selectMenu('/my')"> 个人中心 </el-dropdown-item>
                        <el-dropdown-item divided @click="logout">退出登录</el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </div>
        <!--主-->
        <div style="
                background-color: white;
                width: calc(100vw - 200px);
                height: calc(100vh - 60px);
                position: fixed;
                top: 60px;
                left: 200px;
                overflow-y: auto;
            ">
            <el-config-provider :locale="locale">
                <RouterView></RouterView>
            </el-config-provider>
        </div>
    </div>
    <!-------------------------------------------------->
    <div v-if="userType != '管理员'">
        <!--顶-->
        <div style="
                background-color: #304156;
                border-bottom: 1px solid #e4e7ed;
                width: 100vw;
                height: 60px;
                position: fixed;
                top: 0;
                left: 0;
                box-sizing: border-box;
                display: flex;
                justify-content: space-between;
                align-items: center;
            ">
            <div style="width: 200px; display: flex; align-items: center; margin-left: 20px">
                <img src="/vite.svg" style="width: 25px; height: 25px" />
                <span style="color: white; margin-left: 5px; font-weight: bold; font-size: 14px">{{
        setting.title
    }}</span>
            </div>
            <el-menu :default-active="active" active-text-color="#ffd04b" background-color="#304156" text-color="#fff"
                class="menu" mode="horizontal" :ellipsis="false">
                <el-menu-item v-for="item in setting.getMenu()" :index="item.path" @click="selectMenu(item.path)">
                    <span>{{ item.name }}</span>
                </el-menu-item>
            </el-menu>
            <div style="width: 200px; text-align: right">
                <el-dropdown style="height: 60px">
                    <span class="el-dropdown-link" style="
                            color: var(--el-color-primary);
                            cursor: pointer;
                            display: flex;
                            align-items: center;
                            margin-right: 20px;
                        ">
                        {{ mainStore.curuser.displayName }}
                        <span>（{{ mainStore.userType }}）</span>
                        <el-icon class="el-icon--right">
                            <arrow-down />
                        </el-icon>
                    </span>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="selectMenu('/my')">个人中心</el-dropdown-item>
                            <el-dropdown-item divided @click="logout"> 退出登录 </el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </div>
        </div>
        <!--主-->
        <div style="
                background-color: white;
                width: 100vw;
                height: calc(100vh - 60px);
                position: fixed;
                top: 60px;
                left: 0;
                overflow-y: auto;
                display: flex;
                justify-content: center;
            ">
            <div style="width: 1000px">
                <el-config-provider :locale="locale">
                    <RouterView></RouterView>
                </el-config-provider>
            </div>
        </div>
    </div>
</template>
<script setup>
//                                       _ooOoo_
//                                      o8888888o
//                                      88" . "88
//                                      (| -_- |)
//                                      O\  =  /O
//                                   ____/`---'\____
//                                 .'  \\|     |//  `.
//                                /  \\|||  :  |||//  \
//                               /  _||||| -:- |||||_  \
//                               |   | \\\  -  /'| |   |
//                               | \_|  `\`---'//  |_/ |
//                               \  .-\__ `-. -'__/-.  /
//                             ___`. .'  /--.--\  `. .'___
//                          ."" '<  `.___\_<|>_/___.' _> \"".
//                         | | :  `- \`. ;`. _/; .'/ /  .' ; |
//                         \  \ `-.   \_\_`. _.'_/_/  -' _.' /
//                 ========`-.____`-.___\_____/___.-`____.-'========
//                                    `=---='
//
//                 .............................................
//                          佛祖保佑             永无BUG

import { zhCn } from "element-plus/es/locale/index";
import { onMounted, ref } from "vue";
import { ArrowDown } from "@element-plus/icons-vue";
import { useMainStore } from "@/utils/store.js";
import router from "@/utils/router.js";
import setting from "@/utils/setting.js";
import { useRoute } from "vue-router";

const mainStore = useMainStore();
const locale = zhCn;
const active = ref("");
const userType = sessionStorage.getItem("userType");

//选择菜单
function selectMenu(path) {
    active.value = path;
    router.push(path);
    sessionStorage.setItem("active", path);
}
// 退出登录
function logout() {
    sessionStorage.removeItem("token"); // 移除 token
    sessionStorage.removeItem("usertype"); // 移除用户类型
    sessionStorage.removeItem("active");
    mainStore.curuser = {}; // 清空当前用户信息
    mainStore.tmpData = {};
    router.push("/"); // 重置路由
}

// 在组件挂载完成后执行
onMounted(() => {
    active.value = active.value || sessionStorage.getItem("active") || setting.getFirstMenu();
});
</script>

<style scoped>
/* 隐藏滚动条但仍允许滚动 */
.menu::-webkit-scrollbar {
    display: none;
}

.el-menu-item:hover {
    background-color: black;
}

.el-dropdown-link:focus-visible {
    outline: unset;
}
</style>
